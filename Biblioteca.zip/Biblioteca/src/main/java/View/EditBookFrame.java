package View;

import javax.swing.*;
import java.awt.*;

public class EditBookFrame extends JFrame {
    private JTable table;
    private Font mainFont = new Font("Segoe Print", Font.BOLD, 36);
    private Font font1 = new Font("Times New Roman", Font.BOLD, 14);
    private Font font2 = new Font("Times New Roman", Font.BOLD, 14);
    private Font font3 = new Font("Times New Roman", Font.PLAIN, 12);
    private JComboBox<String> comboBox1;
    private JButton btnEdit;
    private JTextField txtAutor;
    private JTextField txtTitlu;
    private JTextField txtAn;
    private JTextArea txtDescriere;
    private JTextField txtISBN;
    private JTextField txtEditura;
    private JTextField txtStoc;
    private JFrame editBookFrame;

    public JTable getTable() {
        return table;
    }

    public JComboBox<String> getComboBox1() {
        return comboBox1;
    }

    public JButton getBtnEdit() {
        return btnEdit;
    }

    public JTextField getTxtAutor() {
        return txtAutor;
    }

    public JTextField getTxtTitlu() {
        return txtTitlu;
    }

    public JTextField getTxtAn() {
        return txtAn;
    }

    public JTextArea getTxtDescriere() {
        return txtDescriere;
    }

    public JTextField getTxtISBN() {
        return txtISBN;
    }

    public JTextField getTxtEditura() {
        return txtEditura;
    }

    public JTextField getTxtStoc() {
        return txtStoc;
    }

    public JFrame getEditBookFrame() {
        return editBookFrame;
    }

    public EditBookFrame() {
        txtAutor = new JTextField(20);
        txtTitlu = new JTextField(20);
        txtAn = new JTextField(20);
        txtDescriere = new JTextArea(5, 20);
        txtISBN = new JTextField(20);
        txtEditura = new JTextField(20);
        txtStoc = new JTextField(20);
        showEditBookFrame();
    }
    public void showEditBookFrame() {
        editBookFrame = new JFrame("Editează detalii");
        editBookFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        editBookFrame.setSize(500, 600);
        editBookFrame.getContentPane().setBackground(Color.WHITE);
        editBookFrame.setLocationRelativeTo(null);
        editBookFrame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(10, 10, 10, 10);


        JLabel lblAutor = new JLabel("Autor:");
        txtAutor = new JTextField(30);
        JLabel lblTitlu = new JLabel("Titlu:");
        txtTitlu = new JTextField(30);
        JLabel lblAn = new JLabel("An:");
        txtAn = new JTextField(30);
        JLabel lblColectie = new JLabel("Colecție:");
        comboBox1 = new JComboBox<>();
        JLabel lblDescriere = new JLabel("Descriere:");
        txtDescriere = new JTextArea(5, 20);
        txtDescriere.setLineWrap(true);
        txtDescriere.setFont(font3);
        txtDescriere.setWrapStyleWord(true);
        JScrollPane scrollPaneDescriere = new JScrollPane(txtDescriere, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        JLabel lblISBN = new JLabel("ISBN:");
        txtISBN = new JTextField(30);
        JLabel lblEditura = new JLabel("Editură:");
        txtEditura = new JTextField(30);
        JLabel lblStoc = new JLabel("Stoc:");
        txtStoc = new JTextField(30);

        gbc.gridx = 0;
        gbc.gridy = 0;
        editBookFrame.add(lblAutor, gbc);
        gbc.gridx = 1;
        editBookFrame.add(txtAutor, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        editBookFrame.add(lblTitlu, gbc);
        gbc.gridx = 1;
        editBookFrame.add(txtTitlu, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        editBookFrame.add(lblAn, gbc);
        gbc.gridx = 1;
        editBookFrame.add(txtAn, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        editBookFrame.add(lblColectie, gbc);
        gbc.gridx = 1;
        editBookFrame.add(comboBox1, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        editBookFrame.add(lblDescriere, gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        editBookFrame.add(scrollPaneDescriere, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        editBookFrame.add(lblISBN, gbc);
        gbc.gridx = 1;
        editBookFrame.add(txtISBN, gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        editBookFrame.add(lblEditura, gbc);
        gbc.gridx = 1;
        editBookFrame.add(txtEditura, gbc);

        gbc.gridx = 0;
        gbc.gridy = 7;
        editBookFrame.add(lblStoc, gbc);
        gbc.gridx = 1;
        editBookFrame.add(txtStoc, gbc);

        btnEdit = new JButton("Editează detaliile acestei cărți");
        btnEdit.setForeground(Color.WHITE);
        btnEdit.setBackground(Color.BLACK);
        btnEdit.setOpaque(true);
        btnEdit.setBorderPainted(false);
        btnEdit.setFont(font1);
        gbc.gridx = 0;
        gbc.gridy = 8;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;
        gbc.insets = new Insets(20, 0, 0, 0);
        editBookFrame.add(btnEdit, gbc);

        lblAutor.setFont(font1);
        lblTitlu.setFont(font1);
        lblAn.setFont(font1);
        lblColectie.setFont(font1);
        lblDescriere.setFont(font1);
        lblISBN.setFont(font1);
        lblEditura.setFont(font1);
        lblStoc.setFont(font1);

        editBookFrame.setVisible(true);
    }

    public void closeEditBookFrame() {
        if (editBookFrame != null) {
            editBookFrame.dispose();
        }
    }

    public void showMessageDialog(String message) {
        JOptionPane.showMessageDialog(null, message);
    }
}
