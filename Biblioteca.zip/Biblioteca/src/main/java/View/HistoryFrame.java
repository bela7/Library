
package View;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;

public class HistoryFrame extends JFrame {
    private JTable table;

    private Font mainFont = new Font("Segoe Print", Font.BOLD, 26);

    public HistoryFrame(Object[][] bookData) {
        setTitle("Istoric Împrumuturi");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setPreferredSize(new Dimension(1000, 600));
        setLayout(new BorderLayout());

        JLabel lbLoginForm = new JLabel("Istoric lectură", SwingConstants.CENTER);
        lbLoginForm.setFont(mainFont);
        lbLoginForm.setForeground(Color.WHITE);

        JPanel headerPanel = new JPanel();
        headerPanel.setPreferredSize(new Dimension(1000, 90));
        headerPanel.setBackground(Color.BLACK);
        headerPanel.setLayout(new BorderLayout());
        headerPanel.add(lbLoginForm, BorderLayout.CENTER);

        headerPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));

        table = new JTable(bookData, getColumnNames());
        table.setRowHeight(30);
        table.setFont(new Font("Arial", Font.PLAIN, 12));
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        table.setBackground(Color.WHITE);

        // Padding
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            private static final int TOP_PADDING = 20;
            private static final int LEFT_PADDING = 8;
            private static final int BOTTOM_PADDING =20;
            private static final int RIGHT_PADDING = 8;

            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                JLabel label = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                label.setBorder(BorderFactory.createEmptyBorder(TOP_PADDING, LEFT_PADDING, BOTTOM_PADDING, RIGHT_PADDING));
                return label;
            }
        });

        table.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        table.getTableHeader().setBorder(BorderFactory.createLineBorder(Color.BLACK));


        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(1100, 550));

        JPanel scrollPanePanel = new JPanel(new BorderLayout());
        int spacing = 20;
        scrollPanePanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createEmptyBorder(spacing, spacing, spacing, spacing),
                BorderFactory.createLineBorder(Color.BLACK)));
        scrollPanePanel.add(scrollPane);

        add(headerPanel, BorderLayout.NORTH);
        add(scrollPanePanel, BorderLayout.CENTER);

        pack();
        setVisible(true);
    }
    private String[] getColumnNames() {
        return new String[]{"Autor", "Titlu", "An", "Colectie", "Descriere", "ISBN", "Editura", "Data împrumut", "Data Retur"};
    }
}
