package View;

import javax.swing.*;
import java.awt.*;

public class DetailsBookFrame extends JFrame {
    private Font font1 = new Font("Times New Roman", Font.BOLD, 14);
    private Font font2 = new Font("Times New Roman", Font.PLAIN, 12);
    private JButton btnDetaliiCititor;
    private JLabel lblAutor, lblTitlu, lblAn, lblColectie, lblDescriere, lblISBN, lblEditura, lblStoc, lblCititor, lblDataImprumut, lblDataRetur;
    private JFrame detailsBookFrame;


    private JLabel cititor;
    private JTextArea textAreaDescriere;

    public JLabel getCititor() { return cititor; }

    public JLabel getLblAutor() {
        return lblAutor;
    }

    public JLabel getLblTitlu() {
        return lblTitlu;
    }

    public JLabel getLblAn() {
        return lblAn;
    }

    public JLabel getLblColectie() {
        return lblColectie;
    }

    public JLabel getLblDescriere() {
        return lblDescriere;
    }

    public JLabel getLblISBN() { return lblISBN; }

    public JLabel getLblEditura() {
        return lblEditura;
    }

    public JLabel getLblStoc() {
        return lblStoc;
    }

    public JLabel getLblCititor() {
        return lblCititor;
    }

    public JLabel getLblDataImprumut() {
        return lblDataImprumut;
    }

    public JLabel getLblDataRetur() {
        return lblDataRetur;
    }

    public JTextArea getTextAreaDescriere() {
        return textAreaDescriere;
    }


    public DetailsBookFrame() {
        btnDetaliiCititor = new JButton("Vizualizeaza detalii cititor");
        lblAutor = new JLabel();
        lblTitlu = new JLabel();
        lblAn = new JLabel();
        lblColectie = new JLabel();
        lblDescriere = new JLabel();
        lblISBN = new JLabel();
        lblEditura = new JLabel();
        lblStoc = new JLabel();
        lblCititor = new JLabel();
        lblDataImprumut = new JLabel();
        lblDataRetur = new JLabel();

        showDetailsBookFrame();
    }

    public void showDetailsBookFrame() {
        detailsBookFrame = new JFrame("Detalii Carte");
        detailsBookFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        detailsBookFrame.setSize(550, 600);
        detailsBookFrame.getContentPane().setBackground(Color.WHITE);
        detailsBookFrame.setLocationRelativeTo(null);
        detailsBookFrame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(10, 0, 0, 0);

        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel autor = new JLabel("Autor:");
        autor.setFont(font1);
        detailsBookFrame.add(autor, gbc);

        gbc.gridx = 1;
        detailsBookFrame.add(lblAutor, gbc);
        lblAutor.setFont(font2);

        gbc.gridx = 0;
        gbc.gridy++;
        JLabel titlu = new JLabel("Titlu:");
        titlu.setFont(font1);
        detailsBookFrame.add(titlu, gbc);

        gbc.gridx = 1;
        detailsBookFrame.add(lblTitlu, gbc);
        lblTitlu.setFont(font2);

        gbc.gridx = 0;
        gbc.gridy++;
        JLabel an = new JLabel("An publicare:");
        an.setFont(font1);
        detailsBookFrame.add(an, gbc);
        gbc.gridx = 1;
        detailsBookFrame.add(lblAn, gbc);
        lblAn.setFont(font2);

        gbc.gridx = 0;
        gbc.gridy++;
        JLabel colectie = new JLabel("Colecție:");
        colectie.setFont(font1);
        detailsBookFrame.add(colectie, gbc);

        gbc.gridx = 1;
        detailsBookFrame.add(lblColectie, gbc);
        lblColectie.setFont(font2);

        gbc.gridx = 0;
        gbc.gridy++;
        JLabel descriere = new JLabel("Descriere:");
        descriere.setFont(font1);
        detailsBookFrame.add(descriere, gbc);

        gbc.gridx = 1;
        textAreaDescriere = new JTextArea(5, 20);
        textAreaDescriere.setFont(getLblDescriere().getFont());
        textAreaDescriere.setLineWrap(true);
        textAreaDescriere.setWrapStyleWord(true);
        textAreaDescriere.setEditable(false);

        JScrollPane scrollPaneDescriere = new JScrollPane(textAreaDescriere, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPaneDescriere.setPreferredSize(new Dimension(300, 100));

        gbc.gridx = 1;

        detailsBookFrame.add(scrollPaneDescriere, gbc);



        gbc.gridx = 0;
        gbc.gridy++;
        JLabel isbn = new JLabel("ISBN:");
        isbn.setFont(font1);
        detailsBookFrame.add(isbn, gbc);

        gbc.gridx = 1;
        detailsBookFrame.add(lblISBN, gbc);
        lblISBN.setFont(font2);

        gbc.gridx = 0;
        gbc.gridy++;
        JLabel editura = new JLabel("Editura:");
        editura.setFont(font1);
        detailsBookFrame.add(editura, gbc);

        gbc.gridx = 1;
        detailsBookFrame.add(lblEditura, gbc);
        lblEditura.setFont(font2);

        gbc.gridx = 0;
        gbc.gridy++;
        JLabel stoc = new JLabel("Stoc:");
        stoc.setFont(font1);
        detailsBookFrame.add(stoc, gbc);
        gbc.gridx = 1;
        detailsBookFrame.add(lblStoc, gbc);
        lblStoc.setFont(font2);

        gbc.gridx = 0;
        gbc.gridy++;
        cititor = new JLabel("Cititor:");
        cititor.setFont(font1);
        detailsBookFrame.add(cititor, gbc);
        lblCititor.setFont(font2);

        gbc.gridx = 1;
        detailsBookFrame.add(lblCititor, gbc);

        gbc.gridx = 0;
        gbc.gridy++;
        JLabel data1= new JLabel("Data împrumut:  ");
        data1.setFont(font1);
        detailsBookFrame.add(data1, gbc);

        gbc.gridx = 1;
        detailsBookFrame.add(lblDataImprumut, gbc);
        lblDataImprumut.setFont(font2);

        gbc.gridx = 0;
        gbc.gridy++;
        JLabel data2 = new JLabel("Data retur:");
        data2.setFont(font1);
        detailsBookFrame.add(data2, gbc);

        gbc.gridx = 1;
        detailsBookFrame.add(lblDataRetur, gbc);
        lblDataRetur.setFont(font2);

        gbc.gridx = 1;
        gbc.gridy++;
        gbc.insets = new Insets(30, 5, 0, 5);
        btnDetaliiCititor.setForeground(Color.WHITE);
        btnDetaliiCititor.setBackground(Color.BLACK);
        btnDetaliiCititor.setOpaque(true);
        btnDetaliiCititor.setBorderPainted(false);
        btnDetaliiCititor.setFont(font1);
        detailsBookFrame.add(btnDetaliiCititor, gbc);



        detailsBookFrame.setVisible(true);
    }


    public JButton getBtnDetaliiCititor() {
        return btnDetaliiCititor;
    }

    public void closeDetailsBookFrame() {
        if (detailsBookFrame != null) {
            detailsBookFrame.dispose();
        }
    }


}

