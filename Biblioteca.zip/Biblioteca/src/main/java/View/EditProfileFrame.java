package View;

import javax.swing.*;
import java.awt.*;

public class EditProfileFrame extends JFrame {
    private Font font1 = new Font("Times New Roman", Font.BOLD, 14);
    private Font font3 = new Font("Times New Roman", Font.PLAIN, 12);
    private JButton btnSubmit;
    private JTextField txtUsername;
    private JTextField txtNume;
    private JTextField txtPrenume;
    private JTextField txtTelefon;
    private JTextField txtEmail;
    private JFrame editProfileFrame;
    private JPasswordField txtOldPassword;
    private JPasswordField txtNewPassword;
    public JPasswordField getTxtNewPassword() {
        return txtNewPassword;
    }

    public JPasswordField getTxtOldPassword() {
        return txtOldPassword;
    }

    public JButton getBtnSubmit() {
        return btnSubmit;
    }

    public JTextField getTxtUsername() {
        return txtUsername;
    }

    public JTextField getTxtNume() {
        return txtNume;
    }

    public JTextField getTxtPrenume() {
        return txtPrenume;
    }

    public JTextField getTxtTelefon() {
        return txtTelefon;
    }

    public JTextField getTxtEmail() {
        return txtEmail;
    }



    public EditProfileFrame() {
        txtUsername = new JTextField(20);
        txtNume = new JTextField(20);
        txtPrenume = new JTextField(20);
        txtTelefon = new JTextField(20);
        txtEmail = new JTextField(20);
        showEditProfileFrame();
    }

    public void showEditProfileFrame() {
        editProfileFrame = new JFrame("Editează profilul");
        editProfileFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        editProfileFrame.setSize(500, 500);
        editProfileFrame.getContentPane().setBackground(Color.WHITE);
        editProfileFrame.setLocationRelativeTo(null);
        editProfileFrame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel lblUsername = new JLabel("Nume de utilizator:");
        txtUsername = new JTextField(30);
        txtUsername.setEditable(false);  // make it uneditable

        JLabel lblNume = new JLabel("Nume:");
        txtNume = new JTextField(30);

        JLabel lblPrenume = new JLabel("Prenume:");
        txtPrenume = new JTextField(30);

        JLabel lblTelefon = new JLabel("Telefon:");
        txtTelefon = new JTextField(30);

        JLabel lblEmail = new JLabel("Email:");
        txtEmail = new JTextField(30);

        JLabel lblOldPassword = new JLabel("Parola veche:");
        txtOldPassword = new JPasswordField(30);

        JLabel lblNewPassword = new JLabel("Parola nouă:");
        txtNewPassword = new JPasswordField(30);

        gbc.gridx = 0;
        gbc.gridy = 0;
        editProfileFrame.add(lblUsername, gbc);
        gbc.gridx = 1;
        editProfileFrame.add(txtUsername, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        editProfileFrame.add(lblNume, gbc);
        gbc.gridx = 1;
        editProfileFrame.add(txtNume, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        editProfileFrame.add(lblPrenume, gbc);
        gbc.gridx = 1;
        editProfileFrame.add(txtPrenume, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        editProfileFrame.add(lblTelefon, gbc);
        gbc.gridx = 1;
        editProfileFrame.add(txtTelefon, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        editProfileFrame.add(lblEmail, gbc);
        gbc.gridx = 1;
        editProfileFrame.add(txtEmail, gbc);


        gbc.gridx = 0;
        gbc.gridy = 5;
        editProfileFrame.add(lblOldPassword, gbc);
        gbc.gridx = 1;
        editProfileFrame.add(txtOldPassword, gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        editProfileFrame.add(lblNewPassword, gbc);
        gbc.gridx = 1;
        editProfileFrame.add(txtNewPassword, gbc);


        btnSubmit = new JButton("Actualizează profilul");
        btnSubmit.setForeground(Color.WHITE);
        btnSubmit.setBackground(Color.BLACK);
        btnSubmit.setOpaque(true);
        btnSubmit.setBorderPainted(false);
        btnSubmit.setFont(font1);
        gbc.gridx = 0;
        gbc.gridy = 8;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;
        gbc.insets = new Insets(20, 0, 0, 0);
        editProfileFrame.add(btnSubmit, gbc);

        lblUsername.setFont(font1);
        lblNume.setFont(font1);
        lblPrenume.setFont(font1);
        lblTelefon.setFont(font1);
        lblEmail.setFont(font1);
        lblOldPassword.setFont(font1);
        lblNewPassword.setFont(font1);

        editProfileFrame.setVisible(true);
    }

    public void closeEditProfileFrame() {
        if (editProfileFrame != null) {
            editProfileFrame.dispose();
        }
    }
    public void showMessageDialog(String message, String title) {
        JOptionPane.showMessageDialog(null, message, title, JOptionPane.PLAIN_MESSAGE);
    }

}
