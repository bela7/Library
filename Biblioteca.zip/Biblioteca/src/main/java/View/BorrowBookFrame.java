package View;

import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;

import javax.swing.*;
import java.awt.*;
import java.util.Properties;

public class BorrowBookFrame extends JFrame {
    private Font font1 = new Font("Times New Roman", Font.BOLD, 14);
    private Font font2 = new Font("Times New Roman", Font.PLAIN, 12);
    private JButton btnBorrowBook;
    private JLabel lblAutor, lblTitlu, lblAn, lblColectie, lblDescriere, lblISBN, lblEditura;
    private JFrame borrowBookFrame;
    private JDatePickerImpl datePicker;
    private JTextArea textAreaDescriere;

    public JLabel getLblAutor() { return lblAutor; }
    public JLabel getLblTitlu() { return lblTitlu; }
    public JLabel getLblAn() { return lblAn; }
    public JLabel getLblColectie() { return lblColectie; }
    public JLabel getLblDescriere() { return lblDescriere; }
    public JLabel getLblISBN() { return lblISBN; }
    public JLabel getLblEditura() { return lblEditura; }
    public JTextArea getTextAreaDescriere() { return textAreaDescriere; }
    public JDatePickerImpl getDatePicker() { return datePicker; }
    public JButton getBtnBorrowBook() { return btnBorrowBook; }

    public BorrowBookFrame() {
        btnBorrowBook = new JButton("Împrumuta cartea");
        lblAutor = new JLabel();
        lblTitlu = new JLabel();
        lblAn = new JLabel();
        lblColectie = new JLabel();
        lblDescriere = new JLabel();
        lblISBN = new JLabel();
        lblEditura = new JLabel();
        textAreaDescriere = new JTextArea();

        showBorrowBookFrame();
    }

    public void showBorrowBookFrame() {
        borrowBookFrame = new JFrame("Imprumută Carte");
        borrowBookFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        borrowBookFrame.setSize(500, 500);
        borrowBookFrame.getContentPane().setBackground(Color.WHITE);
        borrowBookFrame.setLocationRelativeTo(null);
        borrowBookFrame.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(10, 0, 0, 0);


        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel autor = new JLabel("Autor:");
        autor.setFont(font1);
        borrowBookFrame.add(autor, gbc);

        gbc.gridx = 1;
        borrowBookFrame.add(lblAutor, gbc);
        lblAutor.setFont(font2);

        gbc.gridx = 0;
        gbc.gridy++;
        JLabel titlu = new JLabel("Titlu:");
        titlu.setFont(font1);
        borrowBookFrame.add(titlu, gbc);

        gbc.gridx = 1;
        borrowBookFrame.add(lblTitlu, gbc);
        lblTitlu.setFont(font2);

        gbc.gridx = 0;
        gbc.gridy++;
        JLabel an = new JLabel("An publicare:  ");
        an.setFont(font1);
        borrowBookFrame.add(an, gbc);
        gbc.gridx = 1;
        borrowBookFrame.add(lblAn, gbc);
        lblAn.setFont(font2);

        gbc.gridx = 0;
        gbc.gridy++;
        JLabel colectie = new JLabel("Colecție:");
        colectie.setFont(font1);
        borrowBookFrame.add(colectie, gbc);

        gbc.gridx = 1;
        borrowBookFrame.add(lblColectie, gbc);
        lblColectie.setFont(font2);

        gbc.gridx = 0;
        gbc.gridy++;
        JLabel descriere = new JLabel("Descriere:");
        descriere.setFont(font1);
        borrowBookFrame.add(descriere, gbc);

        gbc.gridx = 1;
        textAreaDescriere = new JTextArea(5, 20);
        textAreaDescriere.setFont(getLblDescriere().getFont());
        textAreaDescriere.setLineWrap(true);
        textAreaDescriere.setWrapStyleWord(true);
        textAreaDescriere.setEditable(false);

        JScrollPane scrollPaneDescriere = new JScrollPane(textAreaDescriere, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPaneDescriere.setPreferredSize(new Dimension(300, 100));

        gbc.gridx = 1;

        borrowBookFrame.add(scrollPaneDescriere, gbc);



        gbc.gridx = 0;
        gbc.gridy++;
        JLabel isbn = new JLabel("ISBN:");
        isbn.setFont(font1);
        borrowBookFrame.add(isbn, gbc);

        gbc.gridx = 1;
        borrowBookFrame.add(lblISBN, gbc);
        lblISBN.setFont(font2);

        gbc.gridx = 0;
        gbc.gridy++;
        JLabel editura = new JLabel("Editura:");
        editura.setFont(font1);
        borrowBookFrame.add(editura, gbc);

        gbc.gridx = 1;
        borrowBookFrame.add(lblEditura, gbc);
        lblEditura.setFont(font2);

        // Date Picker
        UtilDateModel model = new UtilDateModel();
        Properties p = new Properties();
        p.put("text.today", "Today");
        p.put("text.month", "Month");
        p.put("text.year", "Year");
        JDatePanelImpl datePanel = new JDatePanelImpl(model, p);
        datePicker = new JDatePickerImpl(datePanel, new DateLabelFormatter());

        gbc.gridx = 0;
        gbc.gridy++;
        JLabel imprumutLbl = new JLabel("Data împrumut: ");
        imprumutLbl.setFont(font1);
        borrowBookFrame.add(imprumutLbl, gbc);

        gbc.gridx = 1;
        borrowBookFrame.add(datePicker, gbc);

        // Borrow Button
        gbc.gridx = 1;
        gbc.gridy++;
        gbc.insets = new Insets(30, 5, 0, 5);
        btnBorrowBook.setForeground(Color.WHITE);
        btnBorrowBook.setBackground(Color.BLACK);
        btnBorrowBook.setOpaque(true);
        btnBorrowBook.setBorderPainted(false);
        btnBorrowBook.setFont(font1);
        borrowBookFrame.add(btnBorrowBook, gbc);

        borrowBookFrame.setVisible(true);
    }

    public void closeBorrowBookFrame() {
        if (borrowBookFrame != null) {
            borrowBookFrame.dispose();
        }
    }
}
