package View;

import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.LineBorder;


public class LoginView extends JFrame {
    private Font mainFont = new Font("Segoe Print", Font.BOLD, 28);
    private Font font1 = new Font("Segoe Print", Font.BOLD, 22);
    private Font font3 = new Font("Segoe Print", Font.BOLD, 14);
    private Font font2 = new Font("Times New Roman", Font.BOLD, 13);
    private JTextField user;
    private JPasswordField password;
    private JButton btnLogin;
    private JButton btnCancel;
    private JLabel lbUser;
    private JLabel lbPassword;
    Image backgroundImage;

    public LoginView() {
        try {
            File file = new File("src\\book2.jpg");
            backgroundImage = ImageIO.read(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
        initialize();
    }

    private void initialize () {

        setLayout(new BorderLayout());
        setLocationRelativeTo(null);

        setTitle("Autentificare");

        setSize(600, 500);

        JLabel lbLoginForm = new JLabel("Biblioteca Județeană Lucian Blaga", SwingConstants.CENTER);
        lbLoginForm.setFont(mainFont);
        lbLoginForm.setForeground(Color.WHITE);

        JPanel headerPanel = new JPanel();
        headerPanel.setPreferredSize(new Dimension(600, 70));
        headerPanel.setBackground(Color.BLACK);
        headerPanel.setLayout(new BorderLayout());
        headerPanel.add(lbLoginForm, BorderLayout.SOUTH);

        lbUser = new JLabel("Utilizator");
        lbUser.setFont(font1);

        lbPassword = new JLabel("Parola");
        lbPassword.setFont(font1);

        // text fields
        Dimension d = new Dimension(220, 30);
        user = new JTextField();
        user.setFont(font3);
        user.setPreferredSize(d);
        user.setOpaque(false);
        user.setBorder(new LineBorder(Color.BLACK, 1));

        password = new JPasswordField();
        password.setFont(font3);
        password.setPreferredSize(d);
        password.setOpaque(false);
        password.setBorder(new LineBorder(Color.BLACK, 1));


        JPanel userPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        userPanel.add(lbUser);
        userPanel.add(user);
        userPanel.setOpaque(false);

        JPanel passwordPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        passwordPanel.add(lbPassword);
        passwordPanel.add(password);
        passwordPanel.setOpaque(false);

        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(0, 1, 0, 0));
        formPanel.add(userPanel);
        formPanel.add(passwordPanel);
        formPanel.setBorder(BorderFactory.createEmptyBorder(60, 180, 10, 180));
        formPanel.setOpaque(false);


        //Butoane autentificare/anulare

        btnLogin = new JButton("autentificare");
        btnLogin.setFont(font2);

        btnCancel = new JButton("anulare");
        btnCancel.setFont(font2);

        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setLayout(new GridLayout(1, 2, 10, 10));
        buttonsPanel.setBorder(BorderFactory.createEmptyBorder(0, 180, 100, 180));
        buttonsPanel.add(btnLogin);
        buttonsPanel.add(btnCancel);
        buttonsPanel.setOpaque(false);


        // Imagine background
        ImageIcon imageIcon = new ImageIcon(backgroundImage);
        JLabel backgroundLabel = new JLabel(imageIcon);
        backgroundLabel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                Image image = imageIcon.getImage().getScaledInstance(backgroundLabel.getWidth(), backgroundLabel.getHeight(), Image.SCALE_SMOOTH);
                backgroundLabel.setIcon(new ImageIcon(image));
            }
        });
        add(backgroundLabel);

        // Big panel
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setOpaque(false);

        // Adaugare componente la panel
        contentPanel.add(headerPanel, BorderLayout.NORTH);
        contentPanel.add(formPanel, BorderLayout.CENTER);
        contentPanel.add(buttonsPanel, BorderLayout.SOUTH);

        // Contentpanel peste imagine
        backgroundLabel.setLayout(new BorderLayout());
        backgroundLabel.add(contentPanel);

        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public JButton getBtnLogin() {
        return btnLogin;
    }

    public JButton getBtnCancel() {
        return btnCancel;
    }

    public JTextField getUser() {
        return user;
    }

    public JPasswordField getPassword() {
        return password;
    }


    public void mesajEroare() {
        JOptionPane.showMessageDialog(LoginView.this,
                "Utilizator sau parola invalidă",
                "Încearcă din nou",
                JOptionPane.ERROR_MESSAGE);

    }





}

