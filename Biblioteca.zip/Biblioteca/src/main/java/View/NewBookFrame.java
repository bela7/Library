package View;

import javax.swing.*;
import java.awt.*;
import Controller.AdminController;


public class NewBookFrame extends JFrame {
    private AdminController controller;
    private Font mainFont = new Font("Segoe Print", Font.BOLD, 36);
    private Font font1 = new Font("Times New Roman", Font.BOLD, 14);
    private Font font2 = new Font("Times New Roman", Font.BOLD, 14);
    private Font font3 = new Font("Times New Roman", Font.PLAIN, 12);


    JComboBox<String> comboBox1;
    public JButton getBtnSubmit() {
        return btnSubmit;
    }
    private JButton btnSubmit;
    JTextField txtAutor;
    JTextField txtTitlu;
    JTextField txtAn;
    JTextArea txtDescriere;
    JTextField txtISBN;
    JTextField txtEditura;
    private JTextField txtStoc;
    private JFrame addBookFrame;


    public JTextField getTxtAutor() {
        return txtAutor;
    }

    public JTextField getTxtTitlu() {
        return txtTitlu;
    }

    public JTextField getTxtAn() {
        return txtAn;
    }

    public JTextArea getTxtDescriere() {
        return txtDescriere;
    }

    public JTextField getTxtISBN() {
        return txtISBN;
    }

    public JTextField getTxtEditura() {
        return txtEditura;
    }

    public JTextField getTxtStoc() {
        return txtStoc;
    }


    public NewBookFrame() {
        showAddBookFrame();
    }


    public JComboBox<String> getComboBox1() {return comboBox1; }


    public void showAddBookFrame() {
        addBookFrame = new JFrame("Adaugă o carte nouă");
        addBookFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        addBookFrame.setSize(500, 600);
        addBookFrame.getContentPane().setBackground(Color.WHITE);
        addBookFrame.setLocationRelativeTo(null);
        addBookFrame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel lblAutor = new JLabel("Autor:");
        txtAutor = new JTextField(30);
        JLabel lblTitlu = new JLabel("Titlu:");
        txtTitlu = new JTextField(30);
        JLabel lblAn = new JLabel("An:");
        txtAn = new JTextField(30);
        JLabel lblColectie = new JLabel("Colecție:");
        comboBox1 = new JComboBox<>();
        JLabel lblDescriere = new JLabel("Descriere:");
        txtDescriere = new JTextArea(5, 20);
        txtDescriere.setFont(font3);
        txtDescriere.setLineWrap(true);
        JScrollPane scrollPaneDescriere = new JScrollPane(txtDescriere, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        JLabel lblISBN = new JLabel("ISBN:");
        txtISBN = new JTextField(30);
        JLabel lblEditura = new JLabel("Editură:");
        txtEditura = new JTextField(30);
        JLabel lblStoc = new JLabel("Stoc:");
        txtStoc = new JTextField(30);

        gbc.gridx = 0;
        gbc.gridy = 0;
        addBookFrame.add(lblAutor, gbc);
        gbc.gridx = 1;
        addBookFrame.add(txtAutor, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        addBookFrame.add(lblTitlu, gbc);
        gbc.gridx = 1;
        addBookFrame.add(txtTitlu, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        addBookFrame.add(lblAn, gbc);
        gbc.gridx = 1;
        addBookFrame.add(txtAn, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        addBookFrame.add(lblColectie, gbc);
        gbc.gridx = 1;
        addBookFrame.add(comboBox1, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        addBookFrame.add(lblDescriere, gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        addBookFrame.add(scrollPaneDescriere, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        addBookFrame.add(lblISBN, gbc);
        gbc.gridx = 1;
        addBookFrame.add(txtISBN, gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        addBookFrame.add(lblEditura, gbc);
        gbc.gridx = 1;
        addBookFrame.add(txtEditura, gbc);

        gbc.gridx = 0;
        gbc.gridy = 7;
        addBookFrame.add(lblStoc, gbc);
        gbc.gridx = 1;
        addBookFrame.add(txtStoc, gbc);

        btnSubmit = new JButton("Adaugă o carte nouă");
        btnSubmit.setForeground(Color.WHITE);
        btnSubmit.setBackground(Color.BLACK);
        btnSubmit.setOpaque(true);
        btnSubmit.setBorderPainted(false);
        btnSubmit.setFont(font1);

        gbc.gridx = 0;
        gbc.gridy = 8;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(20, 10, 10, 10);

        addBookFrame.add(btnSubmit, gbc);

        lblAutor.setFont(font1);
        txtAutor.setFont(font1);
        lblTitlu.setFont(font1);
        txtTitlu.setFont(font1);
        lblAn.setFont(font1);
        txtAn.setFont(font1);
        lblColectie.setFont(font1);
        comboBox1.setFont(font1);
        lblDescriere.setFont(font1);
        txtDescriere.setFont(font1);
        lblISBN.setFont(font1);
        txtISBN.setFont(font1);
        lblEditura.setFont(font1);
        txtEditura.setFont(font1);
        lblStoc.setFont(font1);
        txtStoc.setFont(font1);

        addBookFrame.setVisible(true);
    }

    public void closeAddBookFrame() {
        if (addBookFrame != null) {
            addBookFrame.dispose();
        }
    }

    public void showMessageDialog(String message) {
        JOptionPane.showMessageDialog(null, message);
    }
}