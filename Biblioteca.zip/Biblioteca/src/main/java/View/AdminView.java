package View;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;
import java.util.Properties;
import javax.swing.table.TableColumnModel;


public class AdminView extends JFrame {
    private JTable table;
    private Font mainFont = new Font("Segoe Print", Font.BOLD, 36);
    private Font font1 = new Font("Times New Roman", Font.BOLD, 14);
    private Font font2 = new Font("Times New Roman", Font.BOLD, 14);
    private Font font3 = new Font("Times New Roman", Font.PLAIN, 12);

    private JComboBox<String> comboBox;
    private JButton buttonAdd;
    private JButton buttonEdit;

    private JButton buttonDetalii;

    private JButton buttonDelete;

    private JTextField cautaTitlu;

    private JButton buttonCauta;
    private JButton filter;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField minYear;
    private JTextField maxYear;
    private JDatePickerImpl datePicker;

    private JButton saveButton;

    private JComboBox<String> sortComboBox;

    private JComboBox<String> statsComboBox;

    private JButton editProfileButton;

    private JButton logoutButton;


    private JComboBox<String> saveComboBox;
    private String saveDialogTitle;


    private JPanel statsPanel;
    private String user;
    public AdminView(String user) {
        this.user = user;
        initUI(user);
    }



    private void initUI(String user) {
        setTitle("Bine ai venit, " + user+ "!");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1680, 820);
        setLocationRelativeTo(null);

        JLabel lbLoginForm = new JLabel("Biblioteca Județeană Lucian Blaga", SwingConstants.CENTER);
        lbLoginForm.setFont(mainFont);
        lbLoginForm.setForeground(Color.WHITE);

        JPanel headerPanel = new JPanel();
        headerPanel.setPreferredSize(new Dimension(1000, 90));
        headerPanel.setBackground(Color.BLACK);
        headerPanel.setLayout(new BorderLayout());
        headerPanel.add(lbLoginForm, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new BorderLayout());
        buttonPanel.setOpaque(false);

        editProfileButton = new JButton("Editează Profil");
        editProfileButton.setForeground(Color.WHITE);
        editProfileButton.setBackground(Color.BLACK);
        editProfileButton.setBorder(new LineBorder(Color.WHITE));
        editProfileButton.setContentAreaFilled(false);
        editProfileButton.setOpaque(true);
        editProfileButton.setFont(font1);

        logoutButton = new JButton("Logout");
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setBackground(Color.BLACK);
        logoutButton.setBorder(new LineBorder(Color.WHITE));
        logoutButton.setContentAreaFilled(false);
        logoutButton.setOpaque(true);
        logoutButton.setFont(font1);

        Dimension buttonSize = new Dimension(120, 25);
        Dimension buttonSize1 = new Dimension(70, 25);
        editProfileButton.setPreferredSize(buttonSize);
        logoutButton.setPreferredSize(buttonSize1);
        Insets margin = new Insets(10, 10, 10, 10);
        editProfileButton.setMargin(margin);
        logoutButton.setMargin(margin);



        buttonPanel.add(editProfileButton, BorderLayout.WEST);
        buttonPanel.add(logoutButton, BorderLayout.EAST);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 0, 8));

        headerPanel.add(buttonPanel, BorderLayout.NORTH);


        // Tabel
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setPreferredSize(new Dimension(1100, 550));

        table = new JTable();
        table.setRowHeight(30);
        table.setFont(font3);
        table.getTableHeader().setFont(font2);
        table.setBackground(Color.WHITE);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            private static final int TOP_PADDING = 8;
            private static final int LEFT_PADDING = 12;
            private static final int BOTTOM_PADDING = 8;
            private static final int RIGHT_PADDING = 12;

            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                JLabel label = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                label.setBorder(BorderFactory.createEmptyBorder(TOP_PADDING, LEFT_PADDING, BOTTOM_PADDING, RIGHT_PADDING));
                return label;
            }
        });


        table.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        table.getTableHeader().setBorder(BorderFactory.createLineBorder(Color.BLACK));

        scrollPane.setViewportView(table);

        JPanel rightPanel = new JPanel();
        rightPanel.setBackground(Color.WHITE);
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setBounds(1160, 0, 400, 600);
        rightPanel.setOpaque(true);
        Dimension textFieldMaxSize = new Dimension(350, 20);
        rightPanel.setAlignmentX(Component.CENTER_ALIGNMENT);


        //Butoane - right pannel

        rightPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        buttonAdd = new JButton("Adaugă o carte");
        buttonAdd.setForeground(Color.WHITE);
        buttonAdd.setBackground(Color.BLACK);
        buttonAdd.setOpaque(true);
        buttonAdd.setBorderPainted(false);
        buttonAdd.setFont(font1);
        rightPanel.add(buttonAdd);


        rightPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        // Button Edit
        buttonEdit = new JButton("Editează cartea");
        buttonEdit.setForeground(Color.WHITE);
        buttonEdit.setBackground(Color.BLACK);
        buttonEdit.setOpaque(true);
        buttonEdit.setBorderPainted(false);
        buttonEdit.setFont(font1);
        rightPanel.add(buttonEdit);


        rightPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        // Button Detalii
        buttonDetalii = new JButton("Vizualizază detalii");
        buttonDetalii.setForeground(Color.WHITE);
        buttonDetalii.setBackground(Color.BLACK);
        buttonDetalii.setOpaque(true);
        buttonDetalii.setBorderPainted(false);
        buttonDetalii.setFont(font1);
        rightPanel.add(buttonDetalii);

        rightPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        // Button 4
        buttonDelete = new JButton("Șterge cartea");
        buttonDelete.setForeground(Color.WHITE);
        buttonDelete.setBackground(Color.BLACK);
        buttonDelete.setOpaque(true);
        buttonDelete.setBorderPainted(false);
        buttonDelete.setFont(font1);
        rightPanel.add(buttonDelete);


        rightPanel.add(Box.createRigidArea(new Dimension(0, 40)));


        // Label Caută
        JLabel label1 = new JLabel("Caută o carte");
        label1.setFont(font1);
        rightPanel.add(label1);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 8)));

        // Text field Caută
        cautaTitlu = new JTextField();
        cautaTitlu.setFont(font1);
        rightPanel.add(cautaTitlu);
        cautaTitlu.setMaximumSize(textFieldMaxSize);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 8)));

        // Button Caută
        buttonCauta = new JButton("Caută");
        buttonCauta.setForeground(Color.WHITE);
        buttonCauta.setBackground(Color.BLACK);
        buttonCauta.setOpaque(true);
        buttonCauta.setBorderPainted(false);
        buttonCauta.setFont(font1);
        rightPanel.add(buttonCauta);

        // Empty
        rightPanel.add(Box.createRigidArea(new Dimension(0, 50)));


// Label imprumut
        JLabel imprumutLbl = new JLabel("Data imprumut");
        imprumutLbl.setFont(font1);
        rightPanel.add(imprumutLbl);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 10)));

// Date picker
        UtilDateModel model = new UtilDateModel();
        Properties p = new Properties();
        p.put("text.today", "Today");
        p.put("text.month", "Month");
        p.put("text.year", "Year");
        JDatePanelImpl datePanel = new JDatePanelImpl(model, p);
        datePicker = new JDatePickerImpl(datePanel, new DateLabelFormatter());

        rightPanel.add(datePicker);

        rightPanel.add(Box.createRigidArea(new Dimension(0, 15)));


// Label Colectie
        JLabel colectieLbl = new JLabel("Selectează colecția");
        colectieLbl.setFont(font1);
        rightPanel.add(colectieLbl);

        rightPanel.add(Box.createRigidArea(new Dimension(0, 5)));

// ComboBox
        comboBox = new JComboBox<>();
        comboBox.setFont(font1);
        comboBox.setMaximumSize(textFieldMaxSize);
        rightPanel.add(comboBox);

// Empty
        rightPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        // Autor Label
        JLabel autorLbl = new JLabel("Autor");
        autorLbl.setFont(font1);
        rightPanel.add(autorLbl);

        rightPanel.add(Box.createRigidArea(new Dimension(0, 5)));

        // Text autor
        textField2 = new JTextField();
        textField2.setFont(font1);
        textField2.setMaximumSize(textFieldMaxSize);
        rightPanel.add(textField2);

// Empty
        rightPanel.add(Box.createRigidArea(new Dimension(0, 15)));
// Label Editura
        JLabel EdituraLbl = new JLabel("Editura");
        EdituraLbl.setFont(font1);
        rightPanel.add(EdituraLbl);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 5)));

// Text field Editura
        textField3 = new JTextField();
        textField3.setFont(font1);
        textField3.setMaximumSize(textFieldMaxSize);
        rightPanel.add(textField3);

        rightPanel.add(Box.createRigidArea(new Dimension(0, 15)));


// Label Aparitie
        JLabel label4 = new JLabel("Aparitie intre anii:");
        label4.setFont(font1);
        rightPanel.add(label4);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 5)));

// Panel interval an
        JPanel yearRangePanel = new JPanel();
        yearRangePanel.setLayout(new BoxLayout(yearRangePanel, BoxLayout.X_AXIS));

// field minim
        minYear = new JTextField();
        minYear.setFont(font1);
        minYear.setMaximumSize(textFieldMaxSize);
        yearRangePanel.add(minYear);

// spacing
        yearRangePanel.add(Box.createRigidArea(new Dimension(5, 0)));

// field maxim
        maxYear = new JTextField();
        maxYear.setFont(font1);
        maxYear.setMaximumSize(textFieldMaxSize);
        yearRangePanel.add(maxYear);


        rightPanel.add(yearRangePanel);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 15)));


// Button filtreaza
        filter = new JButton("Filtreaza");
        filter.setForeground(Color.WHITE);
        filter.setBackground(Color.BLACK);
        filter.setOpaque(true);
        filter.setBorderPainted(false);
        filter.setFont(font1);
        rightPanel.add(filter);


        // Main Panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);


        rightPanel.setPreferredSize(new Dimension(250, 700));
        scrollPane.setPreferredSize(new Dimension(1500, 700));
        scrollPane.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        rightPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));


// Panel tabel si optiuni tabel
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBackground(Color.WHITE);
        centerPanel.add(scrollPane, BorderLayout.CENTER);

// Panel optiuni
        JPanel optionsPanel = new JPanel(new GridLayout(1, 3));
        optionsPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

//  Sortare Autor
        JPanel sortPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        TitledBorder titledBorder = BorderFactory.createTitledBorder("Vizualizare listă cărți");
        titledBorder.setTitleFont(font1);
        sortPanel.setBorder(titledBorder);

        sortComboBox = new JComboBox<>(new String[]{"A-Z", "Z-A"});
        sortComboBox.setFont(font1);
        sortPanel.add(sortComboBox);

        optionsPanel.add(sortPanel);

//  Vizualizare statistici
        statsPanel = new JPanel();// panel pentru afisarea statisticilor

        JPanel statsPane = new JPanel(new FlowLayout(FlowLayout.LEFT));
        TitledBorder statisticsBorder = BorderFactory.createTitledBorder("Vizualizează statistici");
        statisticsBorder.setTitleFont(font1);
        statsPane.setBorder(statisticsBorder);

        statsComboBox = new JComboBox<>(new String[]{"Autori", "Editură", "Colecție"});
        statsComboBox.setFont(font1);
        statsPane.add(statsComboBox);
        optionsPanel.add(statsPane);

// Third column - Salvează lista
        JPanel savePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        TitledBorder saveBorder = BorderFactory.createTitledBorder("Salvează lista de cărți");
        saveBorder.setTitleFont(font1);
        savePanel.setBorder(saveBorder);

        saveComboBox = new JComboBox<>(new String[]{"TXT", "XML",  "JSON", "CSV"});
        saveComboBox.setFont(font1);
        savePanel.add(saveComboBox);

        saveButton = new JButton("Salvează");
        saveButton.setForeground(Color.WHITE);
        saveButton.setBackground(Color.BLACK);
        saveButton.setOpaque(true);
        saveButton.setBorderPainted(false);
        saveButton.setFont(font1);
        savePanel.add(saveButton);

        optionsPanel.add(savePanel);

// Add the options panel to the center panel
        centerPanel.add(optionsPanel, BorderLayout.SOUTH);

// Add the center panel to the main panel
        mainPanel.add(centerPanel, BorderLayout.CENTER);


        buttonAdd.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonEdit.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonDetalii.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonDelete.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonCauta.setAlignmentX(Component.CENTER_ALIGNMENT);
        label1.setAlignmentX(Component.CENTER_ALIGNMENT);
        cautaTitlu.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonCauta.setAlignmentX(Component.CENTER_ALIGNMENT);
        autorLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        textField2.setAlignmentX(Component.CENTER_ALIGNMENT);
        EdituraLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        textField3.setAlignmentX(Component.CENTER_ALIGNMENT);
        label4.setAlignmentX(Component.CENTER_ALIGNMENT);
        comboBox.setAlignmentX(Component.CENTER_ALIGNMENT);
        colectieLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        datePicker.setAlignmentX(Component.CENTER_ALIGNMENT);
        filter.setAlignmentX(Component.CENTER_ALIGNMENT);


        mainPanel.add(rightPanel, BorderLayout.EAST);

        JPanel contentPane = new JPanel(new BorderLayout());
        contentPane.setBackground(Color.WHITE);
        contentPane.add(headerPanel, BorderLayout.NORTH);
        contentPane.add(mainPanel, BorderLayout.CENTER);

        setContentPane(contentPane);
        setVisible(true);
    }


    public JComboBox<String> getComboBox() {
        return comboBox;
    }

    public JComboBox<String> getStatsComboBox() {return statsComboBox;}

    public JButton getButtonAdd() { return buttonAdd; }
    public JButton getLogoutButton() { return logoutButton; }
    public JButton getButtonEdit() {
        return buttonEdit;
    }

    public JButton getButtonDelete() { return buttonDelete;}

    public JButton getButtonDetalii() { return buttonDetalii; }

    public JButton getButtonCauta() { return buttonCauta; }
    public JButton getFilter() { return filter; }
    public JTextField getCautaTitlu() {return cautaTitlu;}
    public JPanel getStatsPanel() { return statsPanel;}
    public JTable getTable() {
        return table;
    }
    public JComboBox<String> getSaveComboBox() { return saveComboBox;}
    public JTextField getTextFieldAutor() { return textField2; }
    public JTextField getTextFieldEditura() { return textField3; }
    public JTextField getMinYearField() { return minYear; }
    public JTextField getMaxYearField() { return maxYear; }
    public JDatePickerImpl getDatePicker() { return datePicker; }
    public JComboBox<String> getSortComboBox() { return sortComboBox; }

    public JButton getEditProfileButton() { return editProfileButton; }

    public JButton getSaveButton() {return saveButton;}

    public String getSaveDialogTitle() {
        return saveDialogTitle;
    }

    public void setSaveDialogTitle(String saveDialogTitle) {
        this.saveDialogTitle = saveDialogTitle;
    }




    public void displayBooks(Object[][] bookData) {
        DefaultTableModel tableModel = (DefaultTableModel) table.getModel();

        String[] columnNames = {"Autor", "Titlu", "An","Colectie","Descriere", "ISBN", "Editură", "Stoc",  "Cititor", "Data împrumut", "Data Retur"};

        tableModel.setDataVector(bookData, columnNames);

        TableColumnModel columnModel = table.getColumnModel();
        columnModel.getColumn(0).setPreferredWidth(100); //autor
        columnModel.getColumn(1).setPreferredWidth(200); //titlu
        columnModel.getColumn(2).setPreferredWidth(50); //an
        columnModel.getColumn(3).setPreferredWidth(70); //colectie
        columnModel.getColumn(4).setPreferredWidth(200); //descriere
        columnModel.getColumn(5).setPreferredWidth(70); //isbn
        columnModel.getColumn(6).setPreferredWidth(70); //editura
        columnModel.getColumn(7).setPreferredWidth(7); //Stoc
        columnModel.getColumn(8).setPreferredWidth(50); //cititor
        columnModel.getColumn(9).setPreferredWidth(90); //imprumut
        columnModel.getColumn(10).setPreferredWidth(70); //retur


    }


    public void showStatisticsWindow() {
        JFrame statisticsFrame = new JFrame("Statistici");
        statisticsFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        statisticsFrame.setContentPane(getStatsPanel());
        statisticsFrame.pack();
        statisticsFrame.setLocationRelativeTo(null);
        statisticsFrame.setVisible(true);
    }
    public Object[] getRowData(JTable table, int row) {
        int columnCount = table.getColumnCount();
        Object[] rowData = new Object[columnCount];

        for (int i = 0; i < columnCount; i++) {
            rowData[i] = table.getValueAt(row, i);
        }

        return rowData;
    }

    public void showMessageDialog(String message, String title) {
        JOptionPane.showMessageDialog(null, message, title, JOptionPane.INFORMATION_MESSAGE);
    }

}