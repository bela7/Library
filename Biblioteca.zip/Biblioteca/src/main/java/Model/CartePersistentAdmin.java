package Model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CartePersistentAdmin {


    private Carte carte;
    private Imprumut imprumut;

    public Carte getCarte() {
        return carte;
    }

    public void setCarte(Carte carte) {
        this.carte = carte;
    }

    public Imprumut getImprumut() {
        return imprumut;
    }

    public void setImprumut(Imprumut imprumut) {
        this.imprumut = imprumut;
    }

    public List<CartePersistentAdmin> getAllBooks() throws SQLException {
        List<CartePersistentAdmin> books = new ArrayList<>();

        String query = "SELECT c.*, i.username, i.data_imprumut, i.data_retur " +
                "FROM carte c " +
                "LEFT JOIN imprumuturi i ON c.isbn = i.isbn " +
                "ORDER BY c.autor ASC";

        try (Connection connection = DatabaseConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery(query)) {

            while (rs.next()) {
                Carte carte = new Carte();
                carte.setIsbn(rs.getString("isbn"));
                carte.setAutor(rs.getString("autor"));
                carte.setTitlu(rs.getString("titlu"));
                carte.setEditura(rs.getString("editura"));
                carte.setAn(rs.getInt("an_publicare"));
                carte.setColectie(rs.getString("colectie"));
                carte.setDescriere(rs.getString("descriere"));
                carte.setStoc(rs.getInt("stoc"));

                Imprumut imprumut = new Imprumut();
                imprumut.setUsername(rs.getString("username"));
                imprumut.setDataImprumut(rs.getDate("data_imprumut"));
                imprumut.setDataRetur(rs.getDate("data_retur"));


                CartePersistentAdmin book = new CartePersistentAdmin();
                book.setCarte(carte);
                book.setImprumut(imprumut);
                books.add(book);
            }
        }
        return books;
    }


    public List<CartePersistentAdmin> getBooksSortedByAuthorAsc() throws SQLException {
        List<CartePersistentAdmin> books = new ArrayList<>();

        String sql = "SELECT c.*, i.username, i.data_imprumut, i.data_retur " +
                "FROM carte c " +
                "LEFT JOIN imprumuturi i ON c.isbn = i.isbn " +
                "ORDER BY c.autor ASC";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = conn.prepareStatement(sql)) {

            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                Carte carte = new Carte();
                carte.setIsbn(rs.getString("isbn"));
                carte.setAutor(rs.getString("autor"));
                carte.setTitlu(rs.getString("titlu"));
                carte.setEditura(rs.getString("editura"));
                carte.setAn(rs.getInt("an_publicare"));
                carte.setColectie(rs.getString("colectie"));
                carte.setDescriere(rs.getString("descriere"));
                carte.setStoc(rs.getInt("stoc"));

                Imprumut imprumut = new Imprumut();
                imprumut.setUsername(rs.getString("username"));
                imprumut.setDataImprumut(rs.getDate("data_imprumut"));
                imprumut.setDataRetur(rs.getDate("data_retur"));


                CartePersistentAdmin book = new CartePersistentAdmin();
                book.setCarte(carte);
                book.setImprumut(imprumut);
                books.add(book);
            }
        }

        return books;
    }

    public List<CartePersistentAdmin> getBooksSortedByAuthorDesc() throws SQLException {
        List<CartePersistentAdmin> books = new ArrayList<>();

        String sql = "SELECT c.*, i.username, i.data_imprumut, i.data_retur " +
                "FROM carte c " +
                "LEFT JOIN imprumuturi i ON c.isbn = i.isbn " +
                "ORDER BY c.autor DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = conn.prepareStatement(sql)) {

            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                Carte carte = new Carte();
                carte.setIsbn(rs.getString("isbn"));
                carte.setAutor(rs.getString("autor"));
                carte.setTitlu(rs.getString("titlu"));
                carte.setEditura(rs.getString("editura"));
                carte.setAn(rs.getInt("an_publicare"));
                carte.setColectie(rs.getString("colectie"));
                carte.setDescriere(rs.getString("descriere"));
                carte.setStoc(rs.getInt("stoc"));

                Imprumut imprumut = new Imprumut();
                imprumut.setUsername(rs.getString("username"));
                imprumut.setDataImprumut(rs.getDate("data_imprumut"));
                imprumut.setDataRetur(rs.getDate("data_retur"));


                CartePersistentAdmin book = new CartePersistentAdmin();
                book.setCarte(carte);
                book.setImprumut(imprumut);
                books.add(book);
            }
        }

        return books;
    }
    public boolean create(String autor, String titlu, int an, String colectie, String descriere, String isbn, String editura, int stoc) {
        boolean success = false;

        String sql = "INSERT INTO carte (Autor, Titlu, An_publicare, Colectie, Descriere, ISBN, Editura, Stoc) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = conn.prepareStatement(sql)) {

            preparedStatement.setString(1, autor);
            preparedStatement.setString(2, titlu);
            preparedStatement.setInt(3, an);
            preparedStatement.setString(4, colectie);
            preparedStatement.setString(5, descriere);
            preparedStatement.setString(6, isbn);
            preparedStatement.setString(7, editura);
            preparedStatement.setInt(8, stoc);

            preparedStatement.executeUpdate();
            success = true;
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return success;
    }
    public boolean update(String oldISBN, String autor, String titlu, int an, String colectie, String descriere, String isbn, String editura, int stoc) {
        boolean success = false;

        String sql = "UPDATE carte SET Autor = ?, Titlu = ?, An_publicare = ?, Colectie = ?, Descriere = ?, ISBN = ?, Editura = ?, Stoc = ? WHERE ISBN = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = conn.prepareStatement(sql)) {

            preparedStatement.setString(1, autor);
            preparedStatement.setString(2, titlu);
            preparedStatement.setInt(3, an);
            preparedStatement.setString(4, colectie);
            preparedStatement.setString(5, descriere);
            preparedStatement.setString(6, isbn);
            preparedStatement.setString(7, editura);
            preparedStatement.setInt(8, stoc);
            preparedStatement.setString(9, oldISBN);

            preparedStatement.executeUpdate();
            success = true;
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return success;
    }

    public boolean deleteBook(String isbn) {
        boolean success = false;

        String sql = "DELETE FROM carte WHERE ISBN = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = conn.prepareStatement(sql)) {

            preparedStatement.setString(1, isbn);

            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                success = true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return success;
    }
    public List<CartePersistentAdmin> searchBookByTitle(String title) {
        List<CartePersistentAdmin> books = new ArrayList<>();

        String sql = "SELECT c.*, i.username, i.data_imprumut, i.data_retur " +
                "FROM carte c " +
                "LEFT JOIN imprumuturi i ON c.isbn = i.isbn " +
                "WHERE LOWER(c.Titlu) LIKE ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = conn.prepareStatement(sql)) {

            preparedStatement.setString(1, "%" + title.toLowerCase() + "%");

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Carte carte = new Carte();
                carte.setIsbn(resultSet.getString("isbn"));
                carte.setAutor(resultSet.getString("autor"));
                carte.setTitlu(resultSet.getString("titlu"));
                carte.setEditura(resultSet.getString("editura"));
                carte.setAn(resultSet.getInt("an_publicare"));
                carte.setColectie(resultSet.getString("colectie"));
                carte.setDescriere(resultSet.getString("descriere"));
                carte.setStoc(resultSet.getInt("stoc"));

                Imprumut imprumut = new Imprumut();
                imprumut.setUsername(resultSet.getString("username"));
                imprumut.setDataImprumut(resultSet.getDate("data_imprumut"));
                imprumut.setDataRetur(resultSet.getDate("data_retur"));

                CartePersistentAdmin book = new CartePersistentAdmin();
                book.setCarte(carte);
                book.setImprumut(imprumut);

                books.add(book);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return books;
    }
    public List<CartePersistentAdmin> filterBooks(String autor, String editura, Integer minYear, Integer maxYear, String colectie, Date dataImprumut) {
        List<CartePersistentAdmin> books = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT c.*, i.username, i.data_imprumut, i.data_retur FROM carte c LEFT JOIN imprumuturi i ON c.isbn = i.isbn WHERE 1=1");

        if (autor != null) {
            sql.append(" AND LOWER(c.autor) LIKE ?");
        }
        if (editura != null) {
            sql.append(" AND LOWER(c.editura) LIKE ?");
        }
        if (minYear != null) {
            sql.append(" AND c.an_publicare >= ?");
        }
        if (maxYear != null) {
            sql.append(" AND c.an_publicare <= ?");
        }
        if (colectie != null && !colectie.equals("Toate colecțiile")) {
            sql.append(" AND c.colectie = ?");
        }
        if (dataImprumut != null) {
            sql.append(" AND i.data_imprumut = ?");
        }

        sql.append(" ORDER BY c.autor ASC;");

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = conn.prepareStatement(sql.toString())) {

            int paramIndex = 1;
            if (autor != null) {
                preparedStatement.setString(paramIndex++, "%" + autor.toLowerCase() + "%");
            }
            if (editura != null) {
                preparedStatement.setString(paramIndex++, "%" + editura.toLowerCase() + "%");
            }
            if (minYear != null) {
                preparedStatement.setInt(paramIndex++, minYear);
            }
            if (maxYear != null) {
                preparedStatement.setInt(paramIndex++, maxYear);
            }
            if (colectie != null && !colectie.equals("Toate colecțiile")) {
                preparedStatement.setString(paramIndex++, colectie);
            }
            if (dataImprumut != null) {
                preparedStatement.setDate(paramIndex++, new java.sql.Date(dataImprumut.getTime()));
            }

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Carte carte = new Carte();
                carte.setIsbn(resultSet.getString("isbn"));
                carte.setAutor(resultSet.getString("autor"));
                carte.setTitlu(resultSet.getString("titlu"));
                carte.setEditura(resultSet.getString("editura"));
                carte.setAn(resultSet.getInt("an_publicare"));
                carte.setColectie(resultSet.getString("colectie"));
                carte.setDescriere(resultSet.getString("descriere"));
                carte.setStoc(resultSet.getInt("stoc"));

                Imprumut imprumut = new Imprumut();
                imprumut.setUsername(resultSet.getString("username"));
                imprumut.setDataImprumut(resultSet.getDate("data_imprumut"));
                imprumut.setDataRetur(resultSet.getDate("data_retur"));

                CartePersistentAdmin book = new CartePersistentAdmin();
                book.setCarte(carte);
                book.setImprumut(imprumut);

                books.add(book);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return books;
    }




        public List<String> getAllColectie() {
        List<String> colecties = new ArrayList<>();
        String sql = "SELECT DISTINCT colectie FROM carte ORDER BY colectie";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String colectie = rs.getString("colectie");
                colecties.add(colectie);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return colecties;
    }


}
