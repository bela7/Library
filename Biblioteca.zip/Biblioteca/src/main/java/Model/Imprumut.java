package Model;

import java.util.Date;

public class Imprumut {


    private String isbn;
    private String username;
    private Date dataImprumut;
    private Date dataRetur;
    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Date getDataImprumut() {
        return dataImprumut;
    }

    public void setDataImprumut(Date dataImprumut) {
        this.dataImprumut = dataImprumut;
    }

    public Date getDataRetur() {
        return dataRetur;
    }

    public void setDataRetur(Date dataRetur) {
        this.dataRetur = dataRetur;
    }


}
