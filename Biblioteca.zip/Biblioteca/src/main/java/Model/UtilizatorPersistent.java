package Model;
import java.sql.*;

public class UtilizatorPersistent {

    public Utilizator cautareUtilizator(String user, String password) {
        Utilizator utilizator = null;

        try {
            Connection conn = DatabaseConnection.getConnection();

            String sql = "SELECT * FROM utilizator WHERE username=? AND parola=?";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, user);
            preparedStatement.setString(2, password);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                utilizator = new Utilizator();
                utilizator.setUser(resultSet.getString("username"));
                utilizator.setParola(resultSet.getString("parola"));
                utilizator.setRol(resultSet.getString("rol"));
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return utilizator;
    }

    public Utilizator getUserDetails(String username) {
        Utilizator utilizator = null;

        try {
            Connection conn = DatabaseConnection.getConnection();

            String sql = "SELECT * FROM utilizator WHERE username=?";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, username);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                utilizator = new Utilizator();
                utilizator.setUser(resultSet.getString("username"));
                utilizator.setNume(resultSet.getString("nume"));
                utilizator.setPrenume(resultSet.getString("prenume"));
                utilizator.setEmail(resultSet.getString("email"));
                utilizator.setTelefon(resultSet.getString("telefon"));
            }

            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return utilizator;
    }

    public boolean verifyPassword(String username, String password) {
        Utilizator utilizator = null;
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "SELECT parola FROM utilizator WHERE username=?";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, username);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                String currentPassword = resultSet.getString("parola");

                if (currentPassword.equals(password)) {
                    return true;
                }
            }
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean update(Utilizator utilizator) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            String sql = "UPDATE utilizator SET parola=?, nume=?, prenume=?, telefon=?, email=? WHERE username=?";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, utilizator.getParola());
            preparedStatement.setString(2, utilizator.getNume());
            preparedStatement.setString(3, utilizator.getPrenume());
            preparedStatement.setString(4, utilizator.getTelefon());
            preparedStatement.setString(5, utilizator.getEmail());
            preparedStatement.setString(6, utilizator.getUser());

            int rowsAffected = preparedStatement.executeUpdate();
            conn.close();

            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}








