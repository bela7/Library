package Controller;

import Model.*;
import View.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.*;
import java.util.List;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


public class AdminController {
    private AdminView view;
    private NewBookFrame view1;
    private EditBookFrame view2;
    private DetailsBookFrame view3;
    private EditProfileFrame view4;
    private UtilizatorPersistent utilizatorPersistent;
    private CartePersistentAdmin cartePersistent;
    private String oldISBN;
    private String user;

    public AdminController() {
    }
    public AdminController(String user) {
        this.utilizatorPersistent = new UtilizatorPersistent();
        this.cartePersistent = new CartePersistentAdmin();
        this.user = user;
        this.view = new AdminView(user);
        showView();
    }

    public void showView() {
        displayBookList();
        colectieComboBox();
        setupListeners();
    }

    private void setupListeners() {
        view.getButtonAdd().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                view1 = new NewBookFrame();
                colectieComboBox1(view1.getComboBox1());
                    view1.getBtnSubmit().addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                            addBook();
                        }
                    });
            }
        });

        view.getEditProfileButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                view4 = new EditProfileFrame();
                populateEditProfileFields(user);

                view4.getBtnSubmit().addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        editProfile();
                    }
                });
            }
        });

        view.getButtonEdit().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int row = view.getTable().getSelectedRow();
                if (row != -1) {
                    view2 = new EditBookFrame();
                    colectieComboBox1(view2.getComboBox1());
                    populateEditFields(row);

                    view2.getBtnEdit().addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                            editBook(oldISBN);
                        }
                    });
                } else {
                    view.showMessageDialog("Selectati cartea pe care doriti sa o editati.", "Editare carte");
                }
            }
        });

        view.getLogoutButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                logout();
            }
        });

        view.getButtonDetalii().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int row = view.getTable().getSelectedRow();
                if (row != -1) {
                    view3 = new DetailsBookFrame();
                    viewDetails(row);
                    view3.getBtnDetaliiCititor().addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                            detaliiCititor();
                        }
                    });
                } else {
                    view.showMessageDialog("Selectati cartea pe care doriți să o vizualizați.", "Vizualizare carte");
                }
            }
        });

        view.getButtonDelete().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int row = view.getTable().getSelectedRow();
                if (row != -1) {
                    delete(row);
                } else {
                    view.showMessageDialog("Selectati cartea pe care doriți să o ștergeți.", "Ștergere carte");
                }
            }
        });

        view.getButtonCauta().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String titlu = view.getCautaTitlu().getText();
                search(titlu);
            }
        });

        view.getFilter().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleFilterBooks();
            }
        });

        view.getSortComboBox().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleSortBookbyAuthor();
            }
        });

        view.getStatsComboBox().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleStatistics();
            }
        });

        view.getSaveButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleSave();
            }
        });



    }

    public void populateEditProfileFields(String username) {
        Utilizator user = utilizatorPersistent.getUserDetails(username);

        view4.getTxtUsername().setText(user.getUser());
        view4.getTxtNume().setText(user.getNume());
        view4.getTxtPrenume().setText(user.getPrenume());
        view4.getTxtTelefon().setText(user.getTelefon());
        view4.getTxtEmail().setText(user.getEmail());
    }


    public void editProfile() {
        Utilizator utilizator = new Utilizator();
        utilizator.setUser(view4.getTxtUsername().getText());
        utilizator.setParola(String.valueOf(view4.getTxtNewPassword().getPassword()));
        utilizator.setNume(view4.getTxtNume().getText());
        utilizator.setPrenume(view4.getTxtPrenume().getText());
        utilizator.setTelefon(view4.getTxtTelefon().getText());
        utilizator.setEmail(view4.getTxtEmail().getText());

        String oldPassword = String.valueOf(view4.getTxtOldPassword().getPassword());
        String username = utilizator.getUser();

        boolean isOldPasswordCorrect = utilizatorPersistent.verifyPassword(username, oldPassword);
        if (isOldPasswordCorrect) {
            boolean success = utilizatorPersistent.update(utilizator);

            if (success) {
                view4.showMessageDialog("Profilul a fost actualizat cu succes.", "Actualizare profil");
                view4.closeEditProfileFrame();
                displayUserDetails();
            } else {
                view4.showMessageDialog("Eroare la actualizarea profilului.", "Eroare la actualizarea profilului.");
            }
        } else {
            view4.showMessageDialog("Parola veche este incorectă.", "Verificare parolă");
        }
    }




    public void displayUserDetails() {
        String username = view4.getTxtUsername().getText();
        Utilizator user = utilizatorPersistent.getUserDetails(username);

        view4.getTxtUsername().setText(user.getUser());
        view4.getTxtNume().setText(user.getNume());
        view4.getTxtPrenume().setText(user.getPrenume());
        view4.getTxtTelefon().setText(user.getTelefon());
        view4.getTxtEmail().setText(user.getEmail());
    }

    public void editBook(String oldISBN) {
        try {
            String autor = view2.getTxtAutor().getText();
            String titlu = view2.getTxtTitlu().getText();
            int an = 0;
            int stoc = 0;

            try {
                an = Integer.parseInt(view2.getTxtAn().getText());
                stoc = Integer.parseInt(view2.getTxtStoc().getText());
            } catch (NumberFormatException e) {
                view2.showMessageDialog("Introduceți un număr valid pentru an și stoc.");
                return;
            }

            if (an < 0 || stoc < 0) {
                view2.showMessageDialog("Anul și stocul nu pot fi numere negative.");
                return;
            }

            String colectie = view2.getComboBox1().getSelectedItem().toString();
            String descriere = view2.getTxtDescriere().getText();
            String newISBN = view2.getTxtISBN().getText();
            String editura = view2.getTxtEditura().getText();

            boolean success = cartePersistent.update(oldISBN, autor, titlu, an, colectie, descriere, newISBN, editura, stoc);

            if (success) {
                view2.showMessageDialog("Cartea a fost editată cu succes.");
                view2.closeEditBookFrame();
                displayBookList();
            } else {
                view2.showMessageDialog("Editarea cărții a eșuat. Vă rugăm verificați tipul de date introdus.");
                view2.closeEditBookFrame();
            }
        } catch(Exception e) {
            view2.showMessageDialog("A apărut o eroare neașteptată.");
        }
    }


    public void addBook() {
        try {
            String autor = view1.getTxtAutor().getText();
            String titlu = view1.getTxtTitlu().getText();
            int an = 0;
            int stoc = 0;

            try {
                an = Integer.parseInt(view1.getTxtAn().getText());
                stoc = Integer.parseInt(view1.getTxtStoc().getText());
            } catch(NumberFormatException e) {
                view1.showMessageDialog("Introduceți un număr valid pentru an și stoc.");
                return;
            }

            if (an < 0 || stoc < 0) {
                view1.showMessageDialog("Anul și stocul nu pot fi numere negative.");
                return;
            }

            String colectie = view1.getComboBox1().getSelectedItem().toString();
            String descriere = view1.getTxtDescriere().getText();
            String ISBN = view1.getTxtISBN().getText();
            String editura = view1.getTxtEditura().getText();

            boolean success = cartePersistent.create(autor, titlu, an, colectie, descriere, ISBN, editura, stoc);

            if (success) {
                view1.showMessageDialog("Cartea a fost adăugată cu succes.");
                view1.closeAddBookFrame();
                displayBookList();
            } else {
                view1.showMessageDialog("Eroare la adăugarea cărții.");
                view1.closeAddBookFrame();
            }
        } catch(Exception e) {
            view1.showMessageDialog("A apărut o eroare neașteptată.");
        }
    }




    public void populateEditFields(int row) {
        JTable table = view.getTable();

        Object autorObj = table.getValueAt(row, 0);
        String autor = autorObj == null ? "" : autorObj.toString();

        Object titluObj = table.getValueAt(row, 1);
        String titlu = titluObj == null ? "" : titluObj.toString();

        Object anObj = table.getValueAt(row, 2);
        String an = anObj == null ? "" : anObj.toString();

        Object colectieObj = table.getValueAt(row, 3);
        String colectie = colectieObj == null ? "" : colectieObj.toString();

        Object descriereObj = table.getValueAt(row, 4);
        String descriere = descriereObj == null ? "" : descriereObj.toString();

        Object ISBNObj = table.getValueAt(row, 5);
        String ISBN = ISBNObj == null ? "" : ISBNObj.toString();
        oldISBN = ISBN;

        Object edituraObj = table.getValueAt(row, 6);
        String editura = edituraObj == null ? "" : edituraObj.toString();

        Object stocObj = table.getValueAt(row, 7);
        String stoc = stocObj == null ? "" : stocObj.toString();

        view2.getTxtAutor().setText(autor);
        view2.getTxtTitlu().setText(titlu);
        view2.getTxtAn().setText(an);
        view2.getComboBox1().setSelectedItem(colectie);
        view2.getTxtDescriere().setText(descriere);
        view2.getTxtISBN().setText(ISBN);
        view2.getTxtEditura().setText(editura);
        view2.getTxtStoc().setText(stoc);
    }
    private void logout() {

        String[] options = new String[] {"Da", "Nu"};
        int response = JOptionPane.showOptionDialog(null,
                "Sunteți sigur că doriți să vă delogați?",
                "Confirmare delogare",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);

        if (response == 0) {
            view.dispose();
            LoginController loginController = new LoginController();
            loginController.initialize();
        }

    }

    private void delete(int row) {

        String[] options = new String[] {"Da", "Nu"};
        String isbn = (String) view.getTable().getValueAt(row, 5);
        String title = (String) view.getTable().getValueAt(row, 1);


        int response = JOptionPane.showOptionDialog(null,
                "Sunteți sigur că doriți să ștergeți cartea '" + title + "'?",
                "Confirmare ștergere",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);

        if (response == 0) {
            cartePersistent.deleteBook(isbn);
            displayBookList();
        }

    }

    public void search(String title) {
        List<CartePersistentAdmin> books = cartePersistent.searchBookByTitle(title);

        DefaultTableModel tableModel = (DefaultTableModel) view.getTable().getModel();

        tableModel.setRowCount(0);

        for (CartePersistentAdmin bookPersistent : books) {
            Carte book = bookPersistent.getCarte();
            Imprumut imprumut = bookPersistent.getImprumut();

            tableModel.addRow(new Object[]{
                    book.getAutor(),
                    book.getTitlu(),
                    book.getAn(),
                    book.getColectie(),
                    book.getDescriere(),
                    book.getISBN(),
                    book.getEditura(),
                    book.getStoc(),
                    imprumut.getUsername(),
                    imprumut.getDataImprumut(),
                    imprumut.getDataRetur()
            });
        }
    }
    private void handleStatistics() {
        view.getStatsPanel().removeAll();
        view.getStatsPanel().revalidate();

        String selectedOption = (String) view.getStatsComboBox().getSelectedItem();

        switch (selectedOption) {
            case "Autori":
                generateAuthorChart();
                break;
            case "Editură":
                generatePublisherChart();
                break;
            case "Colecție":
                generateCollectionChart();
                break;
        }

        view.getStatsPanel().repaint();
        view.showStatisticsWindow();
    }

    private void generateAuthorChart() {
        Map<String, Integer> authorData = getTableData(0);
        generatePieChart(authorData, "Autori");
    }

    private void generatePublisherChart() {
        Map<String, Integer> publisherData = getTableData(6);
        generatePieChart(publisherData, "Editură");
    }

    private void generateCollectionChart() {
        Map<String, Integer> collectionData = getTableData(3);
        generatePieChart(collectionData, "Colecție");
    }

    private Map<String, Integer> getTableData(int columnIndex) {
        JTable table = view.getTable();
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        Map<String, Integer> data = new HashMap<>();

        for (int i = 0; i < model.getRowCount(); i++) {
            String key = (String) model.getValueAt(i, columnIndex);
            data.put(key, data.getOrDefault(key, 0) + 1);
        }

        return data;
    }


    private void styleChart(JFreeChart chart) {
        PiePlot plot = (PiePlot) chart.getPlot();
        plot.setLabelGenerator(new StandardPieSectionLabelGenerator("{0}: {2}", new DecimalFormat("0"), new DecimalFormat("0.0%")));
        plot.setBackgroundPaint(Color.WHITE);
        chart.setBackgroundPaint(Color.WHITE);
    }


    private void generatePieChart(Map<String, Integer> data, String title) {
        DefaultPieDataset dataset = createDataset(data);

        JFreeChart pieChart = ChartFactory.createPieChart(title, dataset, true, true, false);
        styleChart(pieChart);

        ChartPanel chartPanel = new ChartPanel(pieChart);
        view.getStatsPanel().setLayout(new BorderLayout());
        view.getStatsPanel().add(chartPanel, BorderLayout.CENTER);
        view.getStatsPanel().revalidate();
    }

    private DefaultPieDataset createDataset(Map<String, Integer> data) {
        DefaultPieDataset dataset = new DefaultPieDataset();
        for (Map.Entry<String, Integer> entry : data.entrySet()) {
            dataset.setValue(entry.getKey(), entry.getValue());
        }
        return dataset;
    }


    public void viewDetails(int row) {
        String autor = (String) view.getTable().getValueAt(row, 0);
        String titlu = (String) view.getTable().getValueAt(row, 1);
        int an = (int) view.getTable().getValueAt(row, 2);
        String colectie = (String) view.getTable().getValueAt(row, 3);
        String descriere = (String) view.getTable().getValueAt(row, 4);
        String isbn = (String) view.getTable().getValueAt(row, 5);
        String editura = (String) view.getTable().getValueAt(row, 6);
        int stoc = (int) view.getTable().getValueAt(row, 7);
        String cititor = (String) view.getTable().getValueAt(row, 8);
        Date dataImprumut = (Date) view.getTable().getValueAt(row, 9);
        Date dataRetur = (Date) view.getTable().getValueAt(row, 10);

        view3.getLblAutor().setText(autor);
        view3.getLblTitlu().setText(titlu);
        view3.getLblAn().setText(String.valueOf(an));
        view3.getLblColectie().setText(colectie);
        view3.getTextAreaDescriere().setText(descriere);
        view3.getLblISBN().setText(isbn);
        view3.getLblEditura().setText(editura);
        view3.getLblStoc().setText(String.valueOf(stoc));

        if (cititor != null) {
            view3.getLblCititor().setText(cititor.toString());
        } else {
            view3.getLblCititor().setText("");
        }

        if (dataImprumut != null) {
            view3.getLblDataImprumut().setText(dataImprumut.toString());
        } else {
            view3.getLblDataImprumut().setText("");
        }

        if (dataRetur != null) {
            view3.getLblDataRetur().setText(dataRetur.toString());
        } else {
            view3.getLblDataRetur().setText("");
        }

    }
    public void handleFilterBooks() {
        String autor = null;
        String editura = null;
        Integer minYear = null;
        Integer maxYear = null;
        String colectie = null;
        java.sql.Date dataImprumut = null;

        try {
            if (!view.getTextFieldAutor().getText().isEmpty()) {
                autor = view.getTextFieldAutor().getText();
            }

            if (!view.getTextFieldEditura().getText().isEmpty()) {
                editura = view.getTextFieldEditura().getText();
            }

            if (!view.getMinYearField().getText().isEmpty()) {
                minYear = Integer.parseInt(view.getMinYearField().getText());
                if (minYear < 0) {
                    view.showMessageDialog("Anul minim nu poate fi negativ.", "Eroare");
                    return;
                }
            }

            if (!view.getMaxYearField().getText().isEmpty()) {
                maxYear = Integer.parseInt(view.getMaxYearField().getText());
                if (maxYear < 0) {
                    view.showMessageDialog("Anul maxim nu poate fi negativ.", "Eroare");
                    return;
                }
            }

            if (minYear != null && maxYear != null && minYear > maxYear) {
                view.showMessageDialog("Anul minim nu poate fi mai mare decât anul maxim.", "Eroare");
                return;
            }

            if (view.getComboBox().getSelectedItem() != null) {
                colectie = (String) view.getComboBox().getSelectedItem();
            }

            if (view.getDatePicker().getModel().getValue() != null) {
                dataImprumut = new java.sql.Date(((java.util.Date)view.getDatePicker().getModel().getValue()).getTime());
            }

            List<CartePersistentAdmin> filteredBooks = cartePersistent.filterBooks(autor, editura, minYear, maxYear, colectie, dataImprumut);

            DefaultTableModel tableModel = (DefaultTableModel) view.getTable().getModel();
            tableModel.setRowCount(0);

            for (CartePersistentAdmin bookPersistent : filteredBooks) {
                Carte book = bookPersistent.getCarte();
                Imprumut imprumut = bookPersistent.getImprumut();
                Object[] row = new Object[] {book.getAutor(), book.getTitlu(), book.getAn(), book.getColectie(), book.getDescriere(), book.getISBN(), book.getEditura(), book.getStoc(), imprumut.getUsername(), imprumut.getDataImprumut(), imprumut.getDataRetur()};
                tableModel.addRow(row);
            }
        } catch(NumberFormatException e) {
            view.showMessageDialog("Introduceți un număr valid pentru anul minim și anul maxim.", "Eroare");
        } catch(Exception e) {
            view.showMessageDialog("A apărut o eroare neașteptată.", "Eroare");
        }
    }


    public void handleSortBookbyAuthor() {
        String sortOption = (String) view.getSortComboBox().getSelectedItem();
        List<CartePersistentAdmin> sortedBooks;

        try {
            if ("A-Z".equals(sortOption)) {
                sortedBooks = cartePersistent.getBooksSortedByAuthorAsc();
            } else {
                sortedBooks = cartePersistent.getBooksSortedByAuthorDesc();
            }

            displayBookList(sortedBooks);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void displayBookList(List<CartePersistentAdmin> books) {
        Object[][] bookData = new Object[books.size()][11];
        for (int i = 0; i < books.size(); i++) {
            CartePersistentAdmin bookPersistent = books.get(i);

            bookData[i][0] = bookPersistent.getCarte().getAutor();
            bookData[i][1] = bookPersistent.getCarte().getTitlu();
            bookData[i][2] = bookPersistent.getCarte().getAn();
            bookData[i][3] = bookPersistent.getCarte().getColectie();
            bookData[i][4] = bookPersistent.getCarte().getDescriere();
            bookData[i][5] = bookPersistent.getCarte().getISBN();
            bookData[i][6] = bookPersistent.getCarte().getEditura();
            bookData[i][7] = bookPersistent.getCarte().getStoc();
            bookData[i][8] = bookPersistent.getImprumut().getUsername();
            bookData[i][9] = bookPersistent.getImprumut().getDataImprumut();
            bookData[i][10] = bookPersistent.getImprumut().getDataRetur();
        }
        view.displayBooks(bookData);
    }
    public void detaliiCititor() {
        String username = view3.getLblCititor().getText();

        UtilizatorPersistent utilizatorPersistent = new UtilizatorPersistent();
        Utilizator utilizator = utilizatorPersistent.getUserDetails(username);

        if (utilizator != null) {
            String details = "Username: " + utilizator.getUser() +
                    "\nNume: " + utilizator.getNume() +
                    "\nPrenume: " + utilizator.getPrenume() +
                    "\nEmail: " + utilizator.getEmail() +
                    "\nTelefon: " + utilizator.getTelefon();

            JOptionPane.showMessageDialog(view3, details);
        } else {
            JOptionPane.showMessageDialog(view3, "Nu a fost găsit utilizatorul în baza de date " + username);
        }
    }

    private void handleSave() {
        String fileFormat = (String) view.getSaveComboBox().getSelectedItem();

        JTable table = view.getTable();

        switch (fileFormat) {
            case "CSV":
                saveTableAsCSV(table);
                break;
            case "JSON":
                saveTableAsJSON(table);
                break;
            case "XML":
                saveTableAsXML(table);
                break;
            case "TXT":
                saveTableAsTXT(table);
                break;
        }
    }
    private void saveTableAsCSV(JTable table) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle(view.getSaveDialogTitle());
        FileNameExtensionFilter filter = new FileNameExtensionFilter("CSV Files", "csv");
        fileChooser.setFileFilter(filter);

        int userSelection = fileChooser.showSaveDialog(view);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            try (Writer writer = new OutputStreamWriter(new FileOutputStream(fileToSave), StandardCharsets.UTF_8)) {
                writer.write("\ufeff"); // Write BOM
                for (int i = 0; i < table.getColumnCount(); i++) {
                    writer.write(table.getColumnName(i));
                    if (i < table.getColumnCount() - 1) {
                        writer.write(",");
                    }
                }
                writer.write("\n");

                for (int i = 0; i < table.getRowCount(); i++) {
                    for (int j = 0; j < table.getColumnCount(); j++) {
                        Object cellValue = table.getValueAt(i, j);
                        if (cellValue != null) {
                            writer.write(cellValue.toString());
                        } else {
                            writer.write("");
                        }
                        if (j < table.getColumnCount() - 1) {
                            writer.write(",");
                        }
                    }
                    writer.write("\n");
                }
                view.showMessageDialog("Lista a fost salvată cu succes!", "Salvare listă");
            } catch (IOException e) {
                view.showMessageDialog("Lista nu a putut fi salvată", "Salvare listă");
                e.printStackTrace();
            }
        }
    }


    private void saveTableAsJSON(JTable table) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle(view.getSaveDialogTitle());
        FileNameExtensionFilter filter = new FileNameExtensionFilter("JSON Files", "json");
        fileChooser.setFileFilter(filter);

        int userSelection = fileChooser.showSaveDialog(view);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();

            JSONArray jsonArray = new JSONArray();

            for (int i = 0; i < table.getRowCount(); i++) {
                JSONObject jsonObject = new JSONObject();
                for (int j = 0; j < table.getColumnCount(); j++) {
                    Object cellValue = table.getValueAt(i, j);
                    if (cellValue != null) {
                        jsonObject.put(table.getColumnName(j), cellValue.toString());
                    } else {
                        jsonObject.put(table.getColumnName(j), "");
                    }
                }
                jsonArray.add(jsonObject);
            }

            try (Writer writer = new OutputStreamWriter(new FileOutputStream(fileToSave), StandardCharsets.UTF_8)) {
                writer.write(jsonArray.toString());
                view.showMessageDialog("Lista a fost salvată cu succes!", "Salvare listă");
            } catch (IOException e) {
                view.showMessageDialog("Lista nu a putut fi salvată", "Salvare listă");
                e.printStackTrace();
            }

        }
    }


    private void saveTableAsXML(JTable table) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle(view.getSaveDialogTitle());
        FileNameExtensionFilter filter = new FileNameExtensionFilter("XML Files", "xml");
        fileChooser.setFileFilter(filter);

        int userSelection = fileChooser.showSaveDialog(view);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            try (FileWriter fw = new FileWriter(fileToSave)) {
                fw.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
                fw.write("<books>\n");

                for (int i = 0; i < table.getRowCount(); i++) {
                    fw.write("  <book>\n");
                    for (int j = 0; j < table.getColumnCount(); j++) {
                        Object cellValue = table.getValueAt(i, j);
                        String cellStringValue = cellValue != null ? cellValue.toString() : "";
                        fw.write(String.format("    <%s>%s</%s>\n", table.getColumnName(j),
                                cellStringValue, table.getColumnName(j)));
                    }
                    fw.write("  </book>\n");
                }
                fw.write("</books>");
                view.showMessageDialog("Lista a fost salvată cu succes!", "Salvare listă");
            } catch (IOException e) {
                view.showMessageDialog("Lista nu a putut fi salvată", "Salvare listă");
                e.printStackTrace();
            }
        }
    }
    private void saveTableAsTXT(JTable table) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle(view.getSaveDialogTitle());
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Text Files", "txt");
        fileChooser.setFileFilter(filter);

        int userSelection = fileChooser.showSaveDialog(view);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            try (FileWriter fw = new FileWriter(fileToSave)) {
                for (int i = 0; i < table.getRowCount(); i++) {
                    for (int j = 0; j < table.getColumnCount(); j++) {
                        Object cellValue = table.getValueAt(i, j);
                        String cellStringValue = cellValue != null ? cellValue.toString() : "";
                        fw.write(cellStringValue);
                        if (j < table.getColumnCount() - 1) {
                            fw.write("\t");
                        }
                    }
                    fw.write("\n");
                }
                view.showMessageDialog("Lista a fost salvată cu succes!", "Salvare listă");
            } catch (IOException e) {
                view.showMessageDialog("Lista nu a putut fi salvată", "Salvare listă");
                e.printStackTrace();
            }
        }
    }

    public void displayBookList() {
        try {
            List<CartePersistentAdmin> books = cartePersistent.getAllBooks();
            Object[][] bookData = new Object[books.size()][11];
            for (int i = 0; i < books.size(); i++) {
                CartePersistentAdmin bookPersistent = books.get(i);

                bookData[i][0] = bookPersistent.getCarte().getAutor();
                bookData[i][1] = bookPersistent.getCarte().getTitlu();
                bookData[i][2] = bookPersistent.getCarte().getAn();
                bookData[i][3] = bookPersistent.getCarte().getColectie();
                bookData[i][4] = bookPersistent.getCarte().getDescriere();
                bookData[i][5] = bookPersistent.getCarte().getISBN();
                bookData[i][6] = bookPersistent.getCarte().getEditura();
                bookData[i][7] = bookPersistent.getCarte().getStoc();
                bookData[i][8] = bookPersistent.getImprumut().getUsername();
                bookData[i][9] = bookPersistent.getImprumut().getDataImprumut();
                bookData[i][10] = bookPersistent.getImprumut().getDataRetur();
            }
            view.displayBooks(bookData);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void colectieComboBox() {
        List<String> colectii = cartePersistent.getAllColectie();
        JComboBox<String> comboBox = view.getComboBox();
        comboBox.removeAllItems();
        comboBox.addItem("Toate colecțiile");

        for (String colectie : colectii) {
            comboBox.addItem(colectie);
        }
    }

    public void colectieComboBox1(JComboBox<String> comboBox1) {
        List<String> colectii = cartePersistent.getAllColectie();
        comboBox1.removeAllItems();

        for (String colectie : colectii) {
            comboBox1.addItem(colectie);
        }
    }





}

