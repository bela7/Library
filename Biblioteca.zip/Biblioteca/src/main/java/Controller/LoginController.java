package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import Model.Utilizator;
import Model.UtilizatorPersistent;
import View.LoginView;



public class LoginController {
    private LoginView view;
    private UtilizatorPersistent utilizatorPersistent;

    public LoginController() {
        this.view = new LoginView();
        this.utilizatorPersistent = new UtilizatorPersistent();

        view.getBtnLogin().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                autentificare();
                view.dispose();
            }
        });
        view.getBtnCancel().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                view.dispose();
            }
        });
    }

    public void initialize() {
        view.setVisible(true);
    }

    public void autentificare() {
        String user = view.getUser().getText();
        String parola = String.valueOf(view.getPassword().getPassword());

        Utilizator utilizator = utilizatorPersistent.cautareUtilizator(user, parola);

        if (utilizator != null) {
            String rol = utilizator.getRol();

            if (rol.equalsIgnoreCase("administrator")) {
                AdminController adminController = new AdminController(user);
            } else if (rol.equalsIgnoreCase("abonat")) {
                UserController adminController = new UserController(user);
            } else {
                view.mesajEroare();
            }
        } else {
            view.mesajEroare();
        }
    }
}