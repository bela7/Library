package Controller;

import Model.*;
import View.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;


public class UserController {
    private UserView view;
    private BorrowBookFrame view1;
    private DetailsBookFrameUser view2;
    private EditProfileFrame view3;
    private ReturnBookFrame returnFrame;
    private UtilizatorPersistent utilizatorPersistent;
    private CartePersistentUser cartePersistent;

    private String user;

    public UserController(String user) {
        this.utilizatorPersistent = new UtilizatorPersistent();
        this.cartePersistent = new CartePersistentUser();
        this.user = user;
        this.view = new UserView(user);
        showView();
    }

    public void showView() {
        displayBookList();
        colectieComboBox();
        setupListeners();
    }

    private void setupListeners() {

        view.getButtonBorrow().addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    int row = view.getTable().getSelectedRow();
                    if (row != -1) {
                        view1 = new BorrowBookFrame();
                        populateBorrowBookFrame(row);

                        view1.getBtnBorrowBook() .addActionListener(new ActionListener() {
                            public void actionPerformed(ActionEvent e) {
                                borrowBook();
                            }
                        });
                    } else {
                        view.showMessageDialog("Selectati cartea pe care doriți să o îmrpumutați.", "Selectati carte");
                    }
                }
        });

        view.getReturnBtn().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int row = view.getTable().getSelectedRow();
                if (row != -1) {
                    returnFrame = new ReturnBookFrame();
                    populateReturnBookFrame(row);

                    returnFrame.getBtnReturnBook() .addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                            returnBook();
                        }
                    });
                } else {
                    view.showMessageDialog("Selectati cartea pe care doriți să o returnați.", "Selectati carte");
                }
            }
        });

        view.getEditProfileButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                view3 = new EditProfileFrame();
                populateEditProfileFields(user);

                view3.getBtnSubmit().addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        editProfile();
                    }
                });
            }
        });

        view.getButtonCauta().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String titlu = view.getCautaTitlu().getText();
                search(titlu);
            }
        });

        view.getFilter().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleFilterBooks();
            }
        });

        view.getSortComboBox().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleSortBookbyAuthor();
            }
        });

        view.getButtonDetalii().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int row = view.getTable().getSelectedRow();
                if (row != -1) {
                    view2 = new DetailsBookFrameUser();
                    populateDetailsBookFrame(row);

                } else {
                    view.showMessageDialog("Selectati cartea pe care doriți să o vizualizați.", "Selectati carte");
                }
            }
        });

        view.getLogoutButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                logout();
            }
        });

        view.getIstoricButton().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                viewHistory();
            }
        });

    }

    private void logout() {

        String[] options = new String[] {"Da", "Nu"};
        int response = JOptionPane.showOptionDialog(null,
                "Sunteți sigur că doriți să vă delogați?",
                "Confirmare delogare",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);

        if (response == 0) {
            view.dispose();
            LoginController loginController = new LoginController();
            loginController.initialize();
        }

    }

    public void populateEditProfileFields(String username) {
        Utilizator user = utilizatorPersistent.getUserDetails(username);

        view3.getTxtUsername().setText(user.getUser());
        view3.getTxtNume().setText(user.getNume());
        view3.getTxtPrenume().setText(user.getPrenume());
        view3.getTxtTelefon().setText(user.getTelefon());
        view3.getTxtEmail().setText(user.getEmail());
    }


    public void editProfile() {
        Utilizator utilizator = new Utilizator();
        utilizator.setUser(view3.getTxtUsername().getText());
        utilizator.setParola(String.valueOf(view3.getTxtNewPassword().getPassword()));
        utilizator.setNume(view3.getTxtNume().getText());
        utilizator.setPrenume(view3.getTxtPrenume().getText());
        utilizator.setTelefon(view3.getTxtTelefon().getText());
        utilizator.setEmail(view3.getTxtEmail().getText());

        String oldPassword = String.valueOf(view3.getTxtOldPassword().getPassword());
        String username = utilizator.getUser();

        boolean isOldPasswordCorrect = utilizatorPersistent.verifyPassword(username, oldPassword);
        if (isOldPasswordCorrect) {
            boolean success = utilizatorPersistent.update(utilizator);

            if (success) {
                view3.showMessageDialog("Profilul a fost actualizat cu succes.", "Actualizare profil");
                view3.closeEditProfileFrame();
                displayUserDetails();
            } else {
                view3.showMessageDialog("Eroare la actualizarea profilului.", "Eroare la actualizarea profilului.");
            }
        } else {
            view3.showMessageDialog("Parola veche este incorectă.", "Verificare parolă");
        }
    }



    public void displayUserDetails() {
        String username = view3.getTxtUsername().getText();
        Utilizator user = utilizatorPersistent.getUserDetails(username);

        view3.getTxtUsername().setText(user.getUser());
        view3.getTxtNume().setText(user.getNume());
        view3.getTxtPrenume().setText(user.getPrenume());
        view3.getTxtTelefon().setText(user.getTelefon());
        view3.getTxtEmail().setText(user.getEmail());

    }

    public void search(String title) {
        List<CartePersistentUser> books = cartePersistent.searchBookByTitle(title);

        DefaultTableModel tableModel = (DefaultTableModel) view.getTable().getModel();

        tableModel.setRowCount(0);

        for (CartePersistentUser bookPersistent : books) {
            Carte book = bookPersistent.getCarte();

            tableModel.addRow(new Object[]{
                    book.getAutor(),
                    book.getTitlu(),
                    book.getAn(),
                    book.getColectie(),
                    book.getDescriere(),
                    book.getISBN(),
                    book.getEditura()
            });
        }
    }
    public void populateBorrowBookFrame(int row) {
        String autor = (String) view.getTable().getValueAt(row, 0);
        String titlu = (String) view.getTable().getValueAt(row, 1);
        int an = (int) view.getTable().getValueAt(row, 2);
        String colectie = (String) view.getTable().getValueAt(row, 3);
        String descriere = (String) view.getTable().getValueAt(row, 4);
        String isbn = (String) view.getTable().getValueAt(row, 5);
        String editura = (String) view.getTable().getValueAt(row, 6);

        view1.getLblAutor().setText(autor);
        view1.getLblTitlu().setText(titlu);
        view1.getLblAn().setText(String.valueOf(an));
        view1.getLblColectie().setText(colectie);
        view1.getTextAreaDescriere().setText(descriere);
        view1.getLblISBN().setText(isbn);
        view1.getLblEditura().setText(editura);

    }

    public void populateReturnBookFrame(int row) {
        String autor = (String) view.getTable().getValueAt(row, 0);
        String titlu = (String) view.getTable().getValueAt(row, 1);
        int an = (int) view.getTable().getValueAt(row, 2);
        String colectie = (String) view.getTable().getValueAt(row, 3);
        String descriere = (String) view.getTable().getValueAt(row, 4);
        String isbn = (String) view.getTable().getValueAt(row, 5);
        String editura = (String) view.getTable().getValueAt(row, 6);

        returnFrame.getLblAutor().setText(autor);
        returnFrame.getLblTitlu().setText(titlu);
        returnFrame.getLblAn().setText(String.valueOf(an));
        returnFrame.getLblColectie().setText(colectie);
        returnFrame.getTextAreaDescriere().setText(descriere);
        returnFrame.getLblISBN().setText(isbn);
        returnFrame.getLblEditura().setText(editura);

    }
    public void populateDetailsBookFrame(int row) {
        String autor = (String) view.getTable().getValueAt(row, 0);
        String titlu = (String) view.getTable().getValueAt(row, 1);
        int an = (int) view.getTable().getValueAt(row, 2);
        String colectie = (String) view.getTable().getValueAt(row, 3);
        String descriere = (String) view.getTable().getValueAt(row, 4);
        String isbn = (String) view.getTable().getValueAt(row, 5);
        String editura = (String) view.getTable().getValueAt(row, 6);

        view2.getLblAutor().setText(autor);
        view2.getLblTitlu().setText(titlu);
        view2.getLblAn().setText(String.valueOf(an));
        view2.getLblColectie().setText(colectie);
        view2.getTextAreaDescriere().setText(descriere);
        view2.getLblISBN().setText(isbn);
        view2.getLblEditura().setText(editura);

    }
    public void borrowBook() {
        java.util.Date utilDate = (java.util.Date) view1.getDatePicker().getModel().getValue();
        java.sql.Date selectedDate = new java.sql.Date(utilDate.getTime());
        String isbn = view1.getLblISBN().getText();

        java.sql.Date today = new java.sql.Date(System.currentTimeMillis());

        if (selectedDate.before(today)) {
            JOptionPane.showMessageDialog(null,
                    "Data selectata este nu este disponibilă. Va rugăm să selectați o dată din viitor.",
                    "Eroare împrumut", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (cartePersistent.borrowBook(isbn, selectedDate, user)) {
            JOptionPane.showMessageDialog(null,
                    "Cartea a fost rezervată. Va rugăm să veniți în data de "
                            + selectedDate + " și să o ridicați.",
                    "Success împrumut", JOptionPane.INFORMATION_MESSAGE);
            view1.closeBorrowBookFrame();
        } else {
            JOptionPane.showMessageDialog(null,
                    "Din păcate, cartea nu este disponibilă in bibliotecă momentan. Va rugăm să contactați personalul bibliotecii pentru disponibilitate.",
                    "Eroare împrumut", JOptionPane.ERROR_MESSAGE);
        }
    }


    public void returnBook() {
        java.util.Date utilDate = (java.util.Date) returnFrame.getDatePicker().getModel().getValue();
        java.sql.Date selectedDate = new java.sql.Date(utilDate.getTime());
        String isbn = returnFrame.getLblISBN().getText();

        java.sql.Date today = new java.sql.Date(System.currentTimeMillis());

        if (selectedDate.before(today)) {
            JOptionPane.showMessageDialog(null,
                    "Data selectata nu este disponibilă. Va rugăm să selectați o dată din viitor.",
                    "Eroare retur", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (cartePersistent.returnBook(isbn, user, selectedDate)) {
            JOptionPane.showMessageDialog(null,
                    "Cartea a fost rezervată pentru retur. Va rugăm să veniți în data de "
                            + selectedDate + " și să o returnați.",
                    "Success retur", JOptionPane.INFORMATION_MESSAGE);
            returnFrame.closeBorrowBookFrame();
        } else {
            JOptionPane.showMessageDialog(null,
                    "Din păcate, cartea nu poate fi returnată acum. Va rugăm să contactați personalul bibliotecii.",
                    "Eroare împrumut", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void viewHistory() {
        List<CartePersistentUser> books = cartePersistent.getUserBooks(user);
        Object[][] bookData = convertToBookDataArray(books);

        HistoryFrame historyFrame = new HistoryFrame(bookData);
    }


    private Object[][] convertToBookDataArray(List<CartePersistentUser> books) {
        Object[][] bookData = new Object[books.size()][9];
        for (int i = 0; i < books.size(); i++) {
            CartePersistentUser bookPersistent = books.get(i);

            bookData[i][0] = bookPersistent.getCarte().getAutor();
            bookData[i][1] = bookPersistent.getCarte().getTitlu();
            bookData[i][2] = bookPersistent.getCarte().getAn();
            bookData[i][3] = bookPersistent.getCarte().getColectie();
            bookData[i][4] = bookPersistent.getCarte().getDescriere();
            bookData[i][5] = bookPersistent.getCarte().getISBN();
            bookData[i][6] = bookPersistent.getCarte().getEditura();
            bookData[i][7] = bookPersistent.getImprumut().getDataImprumut();
            bookData[i][8] = bookPersistent.getImprumut().getDataRetur();
        }
        return bookData;
    }

    public void viewDetails(int row) {
        String autor = (String) view.getTable().getValueAt(row, 0);
        String titlu = (String) view.getTable().getValueAt(row, 1);
        int an = (int) view.getTable().getValueAt(row, 2);
        String colectie = (String) view.getTable().getValueAt(row, 3);
        String descriere = (String) view.getTable().getValueAt(row, 4);
        String isbn = (String) view.getTable().getValueAt(row, 5);
        String editura = (String) view.getTable().getValueAt(row, 6);

        view2.getLblAutor().setText(autor);
        view2.getLblTitlu().setText(titlu);
        view2.getLblAn().setText(String.valueOf(an));
        view2.getLblColectie().setText(colectie);
        view2.getTextAreaDescriere().setText(descriere);
        view2.getLblISBN().setText(isbn);
        view2.getLblEditura().setText(editura);


    }
    public void handleFilterBooks() {
        String autor = null;
        String editura = null;
        Integer minYear = null;
        Integer maxYear = null;
        String colectie = null;

        try {
            if (!view.getTextFieldAutor().getText().isEmpty()) {
                autor = view.getTextFieldAutor().getText();
            }

            if (!view.getTextFieldEditura().getText().isEmpty()) {
                editura = view.getTextFieldEditura().getText();
            }

            if (!view.getMinYearField().getText().isEmpty()) {
                minYear = Integer.parseInt(view.getMinYearField().getText());
                if (minYear < 0) {
                    view.showMessageDialog("Anul minim nu poate fi negativ.", "Eroare");
                    return;
                }
            }

            if (!view.getMaxYearField().getText().isEmpty()) {
                maxYear = Integer.parseInt(view.getMaxYearField().getText());
                if (maxYear < 0) {
                    view.showMessageDialog("Anul maxim nu poate fi negativ.","Eroare");
                    return;
                }
            }

            if (minYear != null && maxYear != null && minYear > maxYear) {
                view.showMessageDialog("Anul minim nu poate fi mai mare decât anul maxim.", "Eroare");
                return;
            }

            if (view.getComboBox().getSelectedItem() != null) {
                colectie = (String) view.getComboBox().getSelectedItem();
            }

            List<CartePersistentUser> filteredBooks = cartePersistent.filterBooks(autor, editura, minYear, maxYear, colectie);

            DefaultTableModel tableModel = (DefaultTableModel) view.getTable().getModel();
            tableModel.setRowCount(0);

            for (CartePersistentUser bookPersistent : filteredBooks) {
                Carte book = bookPersistent.getCarte();
                Object[] row = new Object[] {book.getAutor(), book.getTitlu(), book.getAn(), book.getColectie(), book.getDescriere(), book.getISBN(), book.getEditura()};
                tableModel.addRow(row);
            }
        } catch(NumberFormatException e) {
            view.showMessageDialog("Introduceți un număr valid pentru anul minim și anul maxim.", "Eroare");
        } catch(Exception e) {
            view.showMessageDialog("A apărut o eroare neașteptată.", "Eroare");
        }
    }


    public void handleSortBookbyAuthor() {
        String sortOption = (String) view.getSortComboBox().getSelectedItem();
        List<CartePersistentUser> sortedBooks;

        try {
            if ("A-Z".equals(sortOption)) {
                sortedBooks = cartePersistent.getBooksSortedByAuthorAsc();
            } else {
                sortedBooks = cartePersistent.getBooksSortedByAuthorDesc();
            }

            displayBookList(sortedBooks);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void displayBookList(List<CartePersistentUser> books) {
        Object[][] bookData = new Object[books.size()][7];
        for (int i = 0; i < books.size(); i++) {
            CartePersistentUser bookPersistent = books.get(i);

            bookData[i][0] = bookPersistent.getCarte().getAutor();
            bookData[i][1] = bookPersistent.getCarte().getTitlu();
            bookData[i][2] = bookPersistent.getCarte().getAn();
            bookData[i][3] = bookPersistent.getCarte().getColectie();
            bookData[i][4] = bookPersistent.getCarte().getDescriere();
            bookData[i][5] = bookPersistent.getCarte().getISBN();
            bookData[i][6] = bookPersistent.getCarte().getEditura();
        }
        view.displayBooks(bookData);
    }

    public void displayBookList() {
        try {
            List<CartePersistentUser> books = cartePersistent.getAllBooks();
            Object[][] bookData = new Object[books.size()][7];
            for (int i = 0; i < books.size(); i++) {
                CartePersistentUser bookPersistent = books.get(i);

                bookData[i][0] = bookPersistent.getCarte().getAutor();
                bookData[i][1] = bookPersistent.getCarte().getTitlu();
                bookData[i][2] = bookPersistent.getCarte().getAn();
                bookData[i][3] = bookPersistent.getCarte().getColectie();
                bookData[i][4] = bookPersistent.getCarte().getDescriere();
                bookData[i][5] = bookPersistent.getCarte().getISBN();
                bookData[i][6] = bookPersistent.getCarte().getEditura();
            }
            view.displayBooks(bookData);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void colectieComboBox() {
        List<String> colectii = cartePersistent.getAllColectie();
        JComboBox<String> comboBox = view.getComboBox();
        comboBox.removeAllItems();
        comboBox.addItem("Toate colecțiile");

        for (String colectie : colectii) {
            comboBox.addItem(colectie);
        }
    }





}

