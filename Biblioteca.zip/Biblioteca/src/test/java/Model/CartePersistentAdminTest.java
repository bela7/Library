package Model;

import org.junit.jupiter.api.*;

import java.sql.SQLException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CartePersistentAdminTest {
    private static CartePersistentAdmin cartePersistent;

    @BeforeAll
    static void setUpClass() {
        try {
            DatabaseConnection.getConnection();
            cartePersistent = new CartePersistentAdmin();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Nu a putut fi stabilită conexiunea la baza de date", e);
        }
    }


    @BeforeEach
    void setUp() {
        cartePersistent.deleteBook("ISBN123");
    }

    @AfterEach
    void tearDown() {
        cartePersistent.deleteBook("ISBN123");
    }

    @Test
    void testCreateBook() {
        boolean created = cartePersistent.create("Autor", "Titlu", 2023, "Colectie", "Descriere", "ISBN123", "Editura", 10);
        assertTrue(created);
    }

    @Test
    void testUpdateBook() {
        boolean created = cartePersistent.create("Autor", "Titlu", 2023, "Colectie", "Descriere", "ISBN123", "Editura", 10);
        assertTrue(created);

        boolean updated = cartePersistent.update("ISBN123", "NewAutor", "NewTitlu", 2024, "NewColectie", "NewDescriere", "ISBN123", "NewEditura", 5);
        assertTrue(updated);
    }

    @Test
    void testSearchBookByTitle() {
        boolean created = cartePersistent.create("Autor", "Titlu", 2023, "Colectie", "Descriere", "ISBN123", "Editura", 10);
        assertTrue(created);

        List<CartePersistentAdmin> searchResults = cartePersistent.searchBookByTitle("Titlu");
        assertFalse(searchResults.isEmpty());
    }

    @Test
    void testDeleteBook() {
        boolean created = cartePersistent.create("Autor", "Titlu", 2023, "Colectie", "Descriere", "ISBN123", "Editura", 10);
        assertTrue(created);

        boolean deleted = cartePersistent.deleteBook("ISBN123");
        assertTrue(deleted);
    }
}
